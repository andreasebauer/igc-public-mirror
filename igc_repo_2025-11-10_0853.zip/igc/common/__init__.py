# Common utilities (paths, hashing, small helpers)
