from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
sumfile=root/'04_PROVENANCE'/'SHA256SUMS.txt'
failed=[]; n=0
for line in sumfile.read_text().splitlines():
    if not line.strip(): continue
    h, rel=line.split('  ',1); p=root/rel; n+=1
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h: failed.append(rel)
print(f'PASS, {n} files checked, 0 failures' if not failed else f'FAIL, {n} files checked, {len(failed)} failures: {failed}')
sys.exit(1 if failed else 0)
