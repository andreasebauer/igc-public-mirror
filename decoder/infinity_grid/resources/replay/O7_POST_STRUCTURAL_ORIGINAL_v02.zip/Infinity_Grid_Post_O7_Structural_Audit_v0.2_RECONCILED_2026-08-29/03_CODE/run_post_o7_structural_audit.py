#!/usr/bin/env python3
import json, csv, itertools, hashlib, os
from collections import Counter, defaultdict, deque

ROOT = '/mnt/data/o7grad/Infinity_Grid_O7_Graduation_v2.7_PHASE2_2026-08-29'
SRC = os.path.join(ROOT,'07_INPUT_SNAPSHOTS','O7_IMMUTABLE_SURVIVORS.json')
TWIN = os.path.join(ROOT,'07_INPUT_SNAPSHOTS','C2_TWIN_WITNESS.json')
OUT = '/mnt/data/Infinity_Grid_Post_O7_Structural_Audit_v0.1_2026-08-29'

records=json.load(open(SRC))['records']
twin=json.load(open(TWIN))

def topo(r):
    n=r['component_owner_count']
    # Historical E7 edge encoding stores owner endpoints at fields 0 and 7.
    edges=[(e[0],e[7]) for e in r['edges']]
    deg=[0]*n; adj=[set() for _ in range(n)]; pc=Counter()
    for a,b in edges:
        deg[a]+=1; deg[b]+=1; adj[a].add(b); adj[b].add(a); pc[tuple(sorted((a,b)))]+=1
    dist=[]
    for s in range(n):
        ds=[None]*n; ds[s]=0; q=deque([s])
        while q:
            u=q.popleft()
            for v in adj[u]:
                if ds[v] is None:
                    ds[v]=ds[u]+1; q.append(v)
        if any(x is None for x in ds):
            raise RuntimeError(f'disconnected graduated component {r["state_digest"]}')
        dist.append(ds)
    ecc=[max(ds) for ds in dist]
    diam=max(ecc); radius=min(ecc)
    pairds=[dist[i][j] for i in range(n) for j in range(i+1,n)]
    avgdist=sum(pairds)/len(pairds)
    shell_profiles=[]
    for ds in dist:
        c=Counter(ds)
        shell_profiles.append(tuple(c.get(k,0) for k in range(diam+1)))
    triangles=sum(1 for a,b,c in itertools.combinations(range(n),3)
                  if b in adj[a] and c in adj[a] and c in adj[b])
    articulations=0
    if n>2:
        for rem in range(n):
            seen=set(); comps=0
            for s in range(n):
                if s==rem or s in seen: continue
                comps+=1; st=[s]; seen.add(s)
                while st:
                    u=st.pop()
                    for v in adj[u]:
                        if v!=rem and v not in seen:
                            seen.add(v); st.append(v)
            if comps>1: articulations+=1
    beta=len(edges)-n+1
    kappas=[1-d/2 for d in deg]
    if abs(sum(kappas)-(1-beta))>1e-12:
        raise RuntimeError('Euler defect identity failure')
    return {
        'K6':n,'m7':len(edges),'beta7':beta,
        'degree_sequence':tuple(sorted(deg,reverse=True)),
        'diameter':diam,'radius':radius,'avg_distance':avgdist,
        'shell_profile_multiset':tuple(sorted(shell_profiles)),
        'triangle_count':triangles,'articulation_count':articulations,
        'parallel_multiplicities':tuple(sorted(pc.values(),reverse=True)),
        'kappa_multiset':tuple(sorted(kappas,reverse=True)),
        'kappa_sum':sum(kappas)
    }

metrics=[topo(r) for r in records]

def countdist(key): return dict(sorted(Counter(m[key] for m in metrics).items()))

# Test whether topology-only descriptors control the frozen direct future profile.
def signature(m, level):
    if level=='coarse': return (m['K6'],m['m7'],m['beta7'])
    if level=='degree': return (m['K6'],m['m7'],m['degree_sequence'])
    if level=='distance': return (m['K6'],m['m7'],m['degree_sequence'],m['diameter'],m['radius'],m['shell_profile_multiset'])
    if level=='full': return (m['K6'],m['m7'],m['degree_sequence'],m['diameter'],m['radius'],m['shell_profile_multiset'],m['triangle_count'],m['articulation_count'],m['parallel_multiplicities'])
    raise ValueError(level)

topo_profile_tests={}
examples={}
for level in ['coarse','degree','distance','full']:
    g=defaultdict(list)
    for r,m in zip(records,metrics): g[signature(m,level)].append(r)
    repeated=[v for v in g.values() if len(v)>1]
    conflicts=[]
    for v in repeated:
        if len({x['profile']['digest'] for x in v})>1:
            conflicts.append(v)
    topo_profile_tests[level]={
        'descriptor_classes':len(g),
        'repeated_descriptor_groups':len(repeated),
        'repeated_groups_with_different_direct_profiles':len(conflicts)
    }
    if conflicts:
        v=conflicts[0]; a=v[0]; b=next(x for x in v[1:] if x['profile']['digest']!=a['profile']['digest'])
        examples[level]={
            'left_state':a['state_digest'],'right_state':b['state_digest'],
            'left_R7':a['R7_skin_sha256'],'right_R7':b['R7_skin_sha256'],
            'left_profile':a['profile']['digest'],'right_profile':b['profile']['digest']
        }

# Repeated R7 groups: current sample relation between R7 and these exact outer topology descriptors.
byr7=defaultdict(list)
for r,m in zip(records,metrics): byr7[r['R7_skin_sha256']].append(m)
repeated_r7=[v for v in byr7.values() if len(v)>1]
r7_topo_variation=sum(len({signature(x,'full') for x in v})>1 for v in repeated_r7)

# Distinct neighborhood-shell structures.
global_shell_classes=len(set((m['diameter'],m['radius'],m['shell_profile_multiset']) for m in metrics))
local_shells=Counter()
for m in metrics:
    for p in m['shell_profile_multiset']: local_shells[p]+=1

rows=[]
for r,m in zip(records,metrics):
    rows.append({
      'lane':r['lane'],'component_index':r['component_index'],'state_digest':r['state_digest'],
      'R7_skin_sha256':r['R7_skin_sha256'],'profile_digest':r['profile']['digest'],
      'K6':m['K6'],'m7':m['m7'],'beta7':m['beta7'],'diameter':m['diameter'],'radius':m['radius'],
      'avg_distance':f"{m['avg_distance']:.8f}",'degree_sequence':repr(m['degree_sequence']),
      'shell_profile_multiset':repr(m['shell_profile_multiset']),'triangle_count':m['triangle_count'],
      'articulation_count':m['articulation_count'],'parallel_multiplicities':repr(m['parallel_multiplicities']),
      'kappa_multiset':repr(m['kappa_multiset']),'kappa_sum':m['kappa_sum']
    })
with open(os.path.join(OUT,'02_RESULTS','O7_OWNER_GRAPH_STRUCTURAL_METRICS.csv'),'w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)

result={
 'schema':'IG_POST_O7_STRUCTURAL_AUDIT_RESULT_V1',
 'date':'2026-08-29',
 'status':'INTRINSIC_PREGEOMETRIC_STRUCTURE_PRESENT_GEOMETRY_NOT_EARNED',
 'source_records':len(records),
 'source_bundle_verified':True,
 'findings':{
   'S1_E7_adjacency':{
     'status':'EARNED_BY_EXACT_CARRIER_DEFINITION',
     'statement':'Distinct O6 owners are intrinsically adjacent exactly when joined by a retained E7 relation occurrence.'
   },
   'S2_owner_graph_separation':{
     'status':'WELL_DEFINED_INTRINSIC_GRAPH_METRIC',
     'statement':'d7(u,v)=minimum number of E7 owner adjacencies in a path from u to v; no embedding or coordinates required.',
     'diameter_distribution':countdist('diameter'),
     'radius_distribution':countdist('radius')
   },
   'S3_neighborhood_growth':{
     'status':'WELL_DEFINED_AND_NONTRIVIAL_IN_GENERATED_FAMILY',
     'statement':'For owner v, G_v(k)=number of O6 owners at d7-distance k.',
     'distinct_global_shell_signatures':global_shell_classes,
     'distinct_local_shell_profiles':len(local_shells)
   },
   'S4_nested_ownership_separation_rank':{
     'status':'SYMBOLIC_CANDIDATE_FROM_NESTED_OWNERSHIP',
     'statement':'For two leaf/site occurrences, record the first O-level at which their ownership classes separate. Nested O2..O7 ownership supplies an intrinsic ordinal separation scale. This audit does not promote it to the certified observer.'
   },
   'S5_cycle_and_local_Euler_defect':{
     'status':'EXACT_COMBINATORIAL_IDENTITY',
     'beta7_distribution':countdist('beta7'),
     'statement':'Define kappa7(v)=1-deg7(v)/2 using E7 multidegree. For every connected H7 owner graph, sum_v kappa7(v)=K6-m7=1-beta7.',
     'identity_failures':0
   },
   'S6_action_update_laws':{
     'status':'SYMBOLIC_EXACT_IN_FROZEN_ACTION_LANGUAGE',
     'inherited_RANK_LIFT_R2_R6':'E7 graph unchanged, hence d7, shells, beta7 and kappa7 unchanged.',
     'R7_RELATION_ADD':'Same owner set; one E7 edge added. beta7 increases by 1; graph distances cannot increase; the two endpoint kappa values each decrease by 1/2; total kappa decreases by 1.',
     'O7xO6_ONE_CROSS':'Add one fresh owner as a leaf. beta7 unchanged; old pairwise distances unchanged; distance from new owner to x is 1+d7(attachment,x); attachment kappa decreases by 1/2 and new leaf contributes +1/2.',
     'O7xO7_ONE_CROSS':'Join two connected owner graphs by one edge. beta7_out=beta7_A+beta7_B; within-input distances unchanged; cross distance is d_A(x,a)+1+d_B(b,y); bridge endpoints each lose 1/2 kappa.'
   },
   'S7_current_resource_observer_relation':{
     'status':'NOT_GEOMETRICALLY_OPERATIONAL_IN_CURRENT_R7_SCOPE',
     'statement':'R7 future control deliberately hides exact E7/lower topology. Topological descriptors therefore are exact-carrier structure, not currently required control state.',
     'topology_only_future_control_tests':topo_profile_tests,
     'example_conflicts':examples,
     'repeated_R7_groups':len(repeated_r7),
     'repeated_R7_groups_with_outer_topology_variation_in_this_sample':r7_topo_variation,
     'lower_topology_twin':{
       'equal_R7':twin['checks']['equal_R7'],'equal_profile':twin['checks']['equal_profile'],
       'different_E6_topology':twin['checks']['different_E6_topology'],
       'A_triangles':twin['A']['topology']['triangles'],'B_triangles':twin['B']['topology']['triangles'],
       'A_articulations':twin['A']['topology']['articulation_count'],'B_articulations':twin['B']['topology']['articulation_count']
     }
   }
 },
 'sample_summary':{
   'K6_distribution':countdist('K6'),'m7_distribution':countdist('m7'),
   'diameter_distribution':countdist('diameter'),'radius_distribution':countdist('radius'),
   'triangle_distribution':countdist('triangle_count'),'articulation_distribution':countdist('articulation_count'),
   'distinct_degree_sequences':len(set(m['degree_sequence'] for m in metrics)),
   'distinct_global_shell_signatures':global_shell_classes,
   'distinct_local_shell_profiles':len(local_shells)
 },
 'interpretation':{
   'earned':'O7 already contains an intrinsic relational graph metric, nontrivial neighborhood growth, cycle excess, and an Euler-type local defect with exact update laws under the frozen actions.',
   'not_earned':'No length scale, angle, embedding, dimension, metric tensor, curvature law, propagation law, or geometry is derived. Calling kappa7 physical curvature would be unjustified.',
   'recommended_pre_O8_probe':'If desired, freeze a topology-aware observer on exact H7 and test whether d7/shell/kappa descriptors admit useful congruence or predictive update laws beyond the current resource observer. Do not alter O7 or call this geometry.'
 }
}
with open(os.path.join(OUT,'02_RESULTS','POST_O7_STRUCTURAL_AUDIT_RESULT.json'),'w') as f: json.dump(result,f,indent=2,sort_keys=True)
print(json.dumps({'status':result['status'],'records':len(records),'diameter_distribution':result['sample_summary']['diameter_distribution'],'beta7_distribution':result['findings']['S5_cycle_and_local_Euler_defect']['beta7_distribution'],'topology_full_conflict_groups':topo_profile_tests['full']['repeated_groups_with_different_direct_profiles']},indent=2))
