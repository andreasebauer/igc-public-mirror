#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys
root=Path(__file__).resolve().parent
lines=(root/'03_PROVENANCE/SHA256SUMS.txt').read_text().splitlines()
bad=[]; n=0
for line in lines:
    if not line.strip(): continue
    h,rel=line.split('  ',1); p=root/rel; n+=1
    if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h: bad.append(rel)
print(f'PASS {n} files 0 failures' if not bad else f'FAIL {len(bad)}: {bad}')
sys.exit(1 if bad else 0)
