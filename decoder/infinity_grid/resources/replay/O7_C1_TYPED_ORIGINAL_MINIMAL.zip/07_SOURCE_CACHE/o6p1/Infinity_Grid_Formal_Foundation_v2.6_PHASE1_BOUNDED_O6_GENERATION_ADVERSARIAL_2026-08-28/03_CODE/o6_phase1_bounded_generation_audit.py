#!/usr/bin/env python3
"""Infinity Grid v2.6 Phase 1 bounded O6 generation/adversarial audit.

This executable implements the sealed Phase-1 preregistration produced by v2.6
Phase 0. It generates bounded exact O6 states using only O6_RELATION_ADD on
fixed O5 occurrences, audits all connected components, attacks the provisional
R6 resource skin, and checks bounded external closure. It cannot graduate O6.
"""
from __future__ import annotations

import bisect
import collections
import csv
import gzip
import hashlib
import heapq
import inspect
import itertools
import json
import math
import multiprocessing as mp
import os
import random
import struct
import time
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parent.parent
INP = ROOT / "08_INPUTS"
OUT = ROOT / "04_RESULTS"
CKPT = ROOT / "07_PROVENANCE" / "checkpoints"
PN = 7
PARENT_PHASE0_SCIENCE = "c54da7857b77bcd42e7e1508f1a6a9a2cc44bb2c39ad0776f3cf5e3132b4f15f"
PARENT_PHASE0_BUNDLE_SHA = "8172bd0e0486e8c7707e675cc6d4ff38adf1247b8ceb290d3189338ee195c8b9"


def jload(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def jdump(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def shaj(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def mark(stage: str) -> None:
    path = OUT / "STAGE_PROGRESS.txt"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(f"{time.time():.6f}\t{stage}\n")
        handle.flush()


def dist(a, b) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


# ---------------------------------------------------------------------------
# Frozen source algebra
# ---------------------------------------------------------------------------

def load_rules():
    spec = jload(INP / "MATURE_NODE_ALGEBRA_SPEC.json")
    ports = tuple(tuple(x) for x in spec["port_atoms"])
    index = {port: i for i, port in enumerate(ports)}
    pairs = tuple(
        (index[tuple(left)], index[tuple(right)])
        for left, right in spec["ordered_compatible_port_pairs"]
    )
    return ports, pairs


def load_templates():
    rows = []
    with (INP / "MATURE_TEMPLATE_PETRI_TRANSITIONS.csv").open(
        "r", encoding="utf-8", newline=""
    ) as handle:
        for row in csv.DictReader(handle):
            rows.append(
                {
                    "index": int(row["template_index"]),
                    "source": int(row["source_port_index"]),
                    "dp": tuple(int(row[f"inc_{i}"]) for i in range(7)),
                }
            )
    if len(rows) != 77:
        raise AssertionError(f"expected 77 mature templates, got {len(rows)}")
    return tuple(rows)


# ---------------------------------------------------------------------------
# O5 prototypes and O6 exact state
# ---------------------------------------------------------------------------

def nested_o5(payload) -> tuple:
    return tuple(
        tuple(
            tuple(
                tuple((tuple(site[0]), tuple(site[1])) for site in block)
                for block in o3
            )
            for o3 in o4
        )
        for o4 in payload
    )


def load_prototypes():
    pool = jload(INP / "O5_PHASE1_RECONSTRUCTED_PROTOTYPE_POOL.json")
    prototypes = {}
    for raw in pool["prototypes"]:
        accounting = dict(raw["accounting"])
        prototypes[raw["prototype_id"]] = {
            "prototype_id": raw["prototype_id"],
            "o5": nested_o5(raw["ordered_resource_o4_carriers"]),
            "canonical_R5_sha256": raw["canonical_R5_sha256"],
            **accounting,
        }
    pin = jload(INP / "PINNED_ACTUAL_O5_COMPONENT.json")
    pin_id = "PHASE0_PINNED_ACTUAL_O5_COMPONENT"
    prototypes[pin_id] = {
        "prototype_id": pin_id,
        "o5": nested_o5(pin["ordered_resource_o4_carriers"]),
        "canonical_R5_sha256": pin["canonical_R5_sha256"],
        **pin["accounting"],
    }
    return pool, prototypes, pin_id


def canon_block(block: Iterable) -> tuple:
    return tuple(sorted((tuple(p), tuple(f)) for p, f in block))


def canon_o3(o3: Iterable) -> tuple:
    return tuple(sorted(canon_block(block) for block in o3))


def canon_o4(o4: Iterable) -> tuple:
    return tuple(sorted(canon_o3(o3) for o3 in o4))


def canon_o5(o5: Iterable) -> tuple:
    return tuple(sorted(canon_o4(o4) for o4 in o5))


def canon_r6(h6: Iterable) -> tuple:
    return tuple(sorted(canon_o5(o5) for o5 in h6))


def r6_digest(h6: Iterable) -> str:
    return hashlib.sha256(repr(canon_r6(h6)).encode()).hexdigest()


def all_sites_proto(proto_ids, prototypes):
    for c, pid in enumerate(proto_ids):
        for j, o4 in enumerate(prototypes[pid]["o5"]):
            for k, o3 in enumerate(o4):
                for v, block in enumerate(o3):
                    for i, (p, f) in enumerate(block):
                        yield (c, j, k, v, i, p, f)


def action_universe(proto_ids, prototypes, pairs):
    sites = list(all_sites_proto(proto_ids, prototypes))
    by_owner = collections.defaultdict(list)
    for site in sites:
        by_owner[site[0]].append(site)
    actions = []
    for left_owner in range(len(proto_ids)):
        for right_owner in range(left_owner + 1, len(proto_ids)):
            for _, j, k, v, i, _, free_left in by_owner[left_owner]:
                for _, J, K, V, I, _, free_right in by_owner[right_owner]:
                    for a, b in pairs:
                        if free_left[a] > 0 and free_right[b] > 0:
                            actions.append(
                                (left_owner, j, k, v, i, a, right_owner, J, K, V, I, b)
                            )
    return tuple(actions)


def usage(edges):
    result = collections.Counter()
    for c, j, k, v, i, a, d, J, K, V, I, b in edges:
        result[(c, j, k, v, i, a)] += 1
        result[(d, J, K, V, I, b)] += 1
    return result


def base_free(proto_ids, prototypes, c, j, k, v, i, a):
    return prototypes[proto_ids[c]]["o5"][j][k][v][i][1][a]


def valid_action(proto_ids, prototypes, used, edge):
    c, j, k, v, i, a, d, J, K, V, I, b = edge
    return (
        c < d
        and used[(c, j, k, v, i, a)] < base_free(proto_ids, prototypes, c, j, k, v, i, a)
        and used[(d, J, K, V, I, b)] < base_free(proto_ids, prototypes, d, J, K, V, I, b)
    )


def add_edge(edges, edge):
    return tuple(sorted(edges + (edge,)))


STATE_HASH_PREFIX = b"IG-E6-STATE-v1|"


def edge_bytes(edge):
    return struct.pack(">12I", *edge)


def state_payload(edges):
    return STATE_HASH_PREFIX + b"".join(edge_bytes(edge) for edge in edges)


def state_digest(edges):
    return hashlib.sha256(state_payload(edges)).hexdigest()


def graph_components(owner_count, edges):
    adjacency = [set() for _ in range(owner_count)]
    for edge in edges:
        adjacency[edge[0]].add(edge[6])
        adjacency[edge[6]].add(edge[0])
    seen = set()
    result = []
    for start in range(owner_count):
        if start in seen:
            continue
        stack = [start]
        seen.add(start)
        component = []
        while stack:
            node = stack.pop()
            component.append(node)
            for nxt in adjacency[node]:
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        result.append(tuple(sorted(component)))
    return tuple(sorted(result))


def materialize(proto_ids, prototypes, edges):
    used = usage(edges)
    result = []
    for c, pid in enumerate(proto_ids):
        out_o5 = []
        for j, o4 in enumerate(prototypes[pid]["o5"]):
            out_o4 = []
            for k, o3 in enumerate(o4):
                out_o3 = []
                for v, block in enumerate(o3):
                    out_block = []
                    for i, (p, f) in enumerate(block):
                        next_f = tuple(
                            f[a] - used[(c, j, k, v, i, a)] for a in range(PN)
                        )
                        out_block.append((p, next_f))
                    out_o3.append(tuple(out_block))
                out_o4.append(tuple(out_o3))
            out_o5.append(tuple(out_o4))
        result.append(tuple(out_o5))
    return tuple(result)


def state_feature(edges, proto_ids, prototypes):
    owner_count = len(proto_ids)
    used = usage(edges)
    components = graph_components(owner_count, edges)
    degree = [0] * owner_count
    pair_count = collections.Counter()
    type_pairs = set()
    endpoints = set()
    type_use = [0] * PN
    for edge in edges:
        c, j, k, v, i, a, d, J, K, V, I, b = edge
        degree[c] += 1
        degree[d] += 1
        pair_count[(c, d)] += 1
        type_pairs.add((min(a, b), max(a, b)))
        endpoints.add((c, j, k, v, i))
        endpoints.add((d, J, K, V, I))
        type_use[a] += 1
        type_use[b] += 1
    owner_free = []
    for c, pid in enumerate(proto_ids):
        total = 0
        for j, o4 in enumerate(prototypes[pid]["o5"]):
            for k, o3 in enumerate(o4):
                for v, block in enumerate(o3):
                    for i, (_, f) in enumerate(block):
                        total += sum(
                            f[a] - used[(c, j, k, v, i, a)] for a in range(PN)
                        )
        owner_free.append(total)
    beta_total = len(edges) - owner_count + len(components)
    return tuple(
        [
            len(edges),
            len(components),
            beta_total,
            len(type_pairs),
            len(endpoints),
            max(pair_count.values(), default=0),
            min(owner_free),
            max(owner_free),
            sum(owner_free),
        ]
        + sorted(degree)
        + type_use
    )


def farthest(states, proto_ids, prototypes, cap):
    if len(states) <= cap:
        return sorted(states, key=state_digest)
    features = [state_feature(state, proto_ids, prototypes) for state in states]
    width = len(features[0])
    mins = [min(row[i] for row in features) for i in range(width)]
    maxs = [max(row[i] for row in features) for i in range(width)]
    normalized = [
        tuple(
            0.0 if maxs[i] == mins[i] else (row[i] - mins[i]) / (maxs[i] - mins[i])
            for i in range(width)
        )
        for row in features
    ]
    centroid = tuple(sum(row[i] for row in normalized) / len(normalized) for i in range(width))
    digests = [state_digest(state) for state in states]
    start = min(range(len(states)), key=lambda idx: (dist(normalized[idx], centroid), digests[idx]))
    selected = [start]
    chosen = {start}
    while len(selected) < cap:
        best = None
        for idx in range(len(states)):
            if idx in chosen:
                continue
            minimum_distance = min(dist(normalized[idx], normalized[j]) for j in selected)
            if (
                best is None
                or minimum_distance > best[0] + 1e-15
                or (abs(minimum_distance - best[0]) <= 1e-15 and digests[idx] < digests[best[1]])
            ):
                best = (minimum_distance, idx)
        selected.append(best[1])
        chosen.add(best[1])
    return [states[idx] for idx in selected]


# Globals inherited by fork workers. They are execution accelerators only; the
# scientific result is independent of worker count and merge order.
_WORKER_PROTO_IDS = None
_WORKER_PROTOTYPES = None
_WORKER_ACTION_SPACE = None
_WORKER_ACTION_BYTES = None
_WORKER_CAP = None


def _local_reservoir_worker(parent_edges):
    used = usage(parent_edges)
    parent_edge_bytes = tuple(edge_bytes(edge) for edge in parent_edges)
    local_heap = []
    local_keep = {}
    enabled = 0
    for action, encoded_action in zip(_WORKER_ACTION_SPACE, _WORKER_ACTION_BYTES):
        if not valid_action(_WORKER_PROTO_IDS, _WORKER_PROTOTYPES, used, action):
            continue
        enabled += 1
        position = bisect.bisect_left(parent_edges, action)
        payload = STATE_HASH_PREFIX + b"".join(parent_edge_bytes[:position]) + encoded_action + b"".join(parent_edge_bytes[position:])
        digest_bytes = hashlib.sha256(payload).digest()
        digest_hex = digest_bytes.hex()
        digest_int = int.from_bytes(digest_bytes, "big")
        if digest_hex in local_keep:
            continue
        if len(local_keep) < _WORKER_CAP:
            successor = parent_edges[:position] + (action,) + parent_edges[position:]
            local_keep[digest_hex] = successor
            heapq.heappush(local_heap, (-digest_int, digest_hex))
        else:
            largest_hex = local_heap[0][1]
            if digest_hex < largest_hex:
                _, old = heapq.heappop(local_heap)
                local_keep.pop(old, None)
                successor = parent_edges[:position] + (action,) + parent_edges[position:]
                local_keep[digest_hex] = successor
                heapq.heappush(local_heap, (-digest_int, digest_hex))
    return enabled, [(digest, local_keep[digest]) for digest in sorted(local_keep)]


def reservoir_successors(beam, proto_ids, prototypes, action_space, cap):
    global _WORKER_PROTO_IDS, _WORKER_PROTOTYPES, _WORKER_ACTION_SPACE, _WORKER_ACTION_BYTES, _WORKER_CAP
    _WORKER_PROTO_IDS = proto_ids
    _WORKER_PROTOTYPES = prototypes
    _WORKER_ACTION_SPACE = action_space
    _WORKER_ACTION_BYTES = tuple(edge_bytes(action) for action in action_space)
    _WORKER_CAP = cap
    worker_count = max(1, min(int(os.environ.get("O6_PHASE1_WORKERS", "8")), len(beam)))
    if worker_count == 1:
        partials = [_local_reservoir_worker(beam[0])]
    else:
        context = mp.get_context("fork")
        with context.Pool(processes=worker_count) as pool:
            partials = pool.map(_local_reservoir_worker, beam)
    enabled_total = sum(item[0] for item in partials)
    # The global 1024 smallest items must lie in the union of each parent's
    # local 1024 smallest items. Merge deterministically and deduplicate exact
    # successor states by their canonical SHA-256 digest.
    merged = {}
    for _, rows in partials:
        for digest, successor in rows:
            merged.setdefault(digest, successor)
    selected_digests = sorted(merged)[:cap]
    return [merged[digest] for digest in selected_digests], enabled_total


# ---------------------------------------------------------------------------
# Accounting and exact-state validation
# ---------------------------------------------------------------------------

def component_invariants(proto_ids, prototypes, edges, component):
    members = set(component)
    internal_edges = tuple(
        edge for edge in edges if edge[0] in members and edge[6] in members
    )
    K5 = len(component)
    m6 = len(internal_edges)
    N = sum(prototypes[proto_ids[c]]["N"] for c in component)
    U2 = sum(prototypes[proto_ids[c]]["U2"] for c in component)
    m3 = sum(prototypes[proto_ids[c]]["m3"] for c in component)
    m4 = sum(prototypes[proto_ids[c]]["m4"] for c in component)
    m5 = sum(prototypes[proto_ids[c]]["m5"] for c in component)
    d = sum(prototypes[proto_ids[c]]["d"] for c in component)
    r = U2 + m3 + m4 + m5 + m6
    beta6 = m6 - K5 + 1
    carriers = materialize(proto_ids, prototypes, edges)
    F = sum(
        sum(f)
        for c in component
        for o4 in carriers[c]
        for o3 in o4
        for block in o3
        for _, f in block
    )
    P_total = sum(
        sum(p)
        for c in component
        for o4 in carriers[c]
        for o3 in o4
        for block in o3
        for p, _ in block
    )
    direct_used = sum(
        sum(p[a] - f[a] for a in range(PN))
        for c in component
        for o4 in carriers[c]
        for o3 in o4
        for block in o3
        for p, f in block
    )
    beta_flat = r - N + 1
    expected_beta_flat = (
        sum(prototypes[proto_ids[c]]["beta_flat5"] for c in component) + beta6
    )
    degree = collections.Counter()
    for edge in internal_edges:
        degree[edge[0]] += 1
        degree[edge[6]] += 1
    parity = []
    load_checks = []
    for c in component:
        load = sum(
            sum(p[a] - f[a] for a in range(PN))
            for o4 in carriers[c]
            for o3 in o4
            for block in o3
            for p, f in block
        )
        expected_load = 2 * prototypes[proto_ids[c]]["r"] + degree[c]
        parity.append((c, load % 2, degree[c] % 2))
        load_checks.append((c, load, expected_load))
    grade = d + r
    expected_grade = sum(prototypes[proto_ids[c]]["g"] for c in component) + m6
    ok = (
        direct_used == 2 * r
        and beta6 >= 0
        and beta_flat == expected_beta_flat
        and P_total == d + 2 * N
        and F == P_total - 2 * r
        and F == d + 2 - 2 * beta_flat
        and all(left == right for _, left, right in parity)
        and all(load == expected for _, load, expected in load_checks)
        and grade == expected_grade
    )
    return {
        "K5": K5,
        "m6": m6,
        "N": N,
        "U2": U2,
        "m3": m3,
        "m4": m4,
        "m5": m5,
        "d": d,
        "r": r,
        "beta6": beta6,
        "beta_flat": beta_flat,
        "expected_beta_flat": expected_beta_flat,
        "F": F,
        "P": P_total,
        "direct_used": direct_used,
        "parity": parity,
        "load_checks": load_checks,
        "g": grade,
        "expected_g": expected_grade,
        "ok": ok,
    }


def validate_exact_state(proto_ids, prototypes, edges, compatible_pairs):
    pair_set = set(compatible_pairs)
    used = usage(edges)
    failures = []
    for edge in edges:
        c, j, k, v, i, a, d, J, K, V, I, b = edge
        if c >= d:
            failures.append({"kind": "owner_order", "edge": list(edge)})
        if (a, b) not in pair_set:
            failures.append({"kind": "bridge", "edge": list(edge)})
    for key, amount in used.items():
        c, j, k, v, i, a = key
        capacity = base_free(proto_ids, prototypes, c, j, k, v, i, a)
        if amount > capacity:
            failures.append({"kind": "capacity", "endpoint": list(key), "used": amount, "capacity": capacity})
    carriers = materialize(proto_ids, prototypes, edges)
    for c, o5 in enumerate(carriers):
        for j, o4 in enumerate(o5):
            for k, o3 in enumerate(o4):
                for v, block in enumerate(o3):
                    for i, (p, f) in enumerate(block):
                        if any(x < 0 for x in f) or any(f[a] > p[a] for a in range(PN)):
                            failures.append({"kind": "negative_or_overfree", "path": [c, j, k, v, i]})
    return failures


def normalize_component(proto_ids, edges, component):
    old = list(component)
    mapping = {owner: index for index, owner in enumerate(old)}
    next_ids = tuple(proto_ids[owner] for owner in old)
    next_edges = tuple(
        sorted(
            (
                mapping[edge[0]],
                edge[1], edge[2], edge[3], edge[4], edge[5],
                mapping[edge[6]],
                edge[7], edge[8], edge[9], edge[10], edge[11],
            )
            for edge in edges
            if edge[0] in mapping and edge[6] in mapping
        )
    )
    return next_ids, next_edges


# ---------------------------------------------------------------------------
# Multiplicity-aware frozen resource profile (Merkle implementation)
# ---------------------------------------------------------------------------

class _MerkleNode:
    __slots__ = ("tag", "children", "site", "parent", "base_sig")

    def __init__(self, tag, children=(), site=None, parent=None):
        self.tag = tag
        self.children = tuple(children)
        self.site = site
        self.parent = parent
        self.base_sig = ""
        for child in self.children:
            child.parent = self


def _digest_leaf(site):
    p, f = site
    payload = b"SITE|" + json.dumps([list(p), list(f)], separators=(",", ":")).encode()
    return hashlib.sha256(payload).hexdigest()


def _digest_container(tag, child_sigs):
    payload = (tag + "|" + "|".join(sorted(child_sigs))).encode()
    return hashlib.sha256(payload).hexdigest()


def _finalize_merkle(node):
    if node.site is not None:
        node.base_sig = _digest_leaf(node.site)
    else:
        node.base_sig = _digest_container(node.tag, [_finalize_merkle(child) for child in node.children])
    return node.base_sig


def _build_merkle(h6):
    entries = []

    def site_node(path, site):
        leaf = _MerkleNode("SITE", site=site)
        entries.append((*path, site, leaf))
        return leaf

    o5_nodes = []
    for a, o5 in enumerate(h6):
        o4_nodes = []
        for j, o4 in enumerate(o5):
            o3_nodes = []
            for k, o3 in enumerate(o4):
                o2_nodes = []
                for v, block in enumerate(o3):
                    leaves = [site_node((a, j, k, v, i), site) for i, site in enumerate(block)]
                    o2_nodes.append(_MerkleNode("O2", leaves))
                o3_nodes.append(_MerkleNode("O3", o2_nodes))
            o4_nodes.append(_MerkleNode("O4", o3_nodes))
        o5_nodes.append(_MerkleNode("O5", o4_nodes))
    root = _MerkleNode("R6", o5_nodes)
    _finalize_merkle(root)
    return root, entries


def _successor_merkle_sig(root, replacements):
    affected = set()
    for leaf in replacements:
        node = leaf
        while node is not None:
            affected.add(node)
            node = node.parent
    memo = {}

    def rec(node):
        if node in memo:
            return memo[node]
        if node not in affected:
            return node.base_sig
        if node.site is not None:
            signature = _digest_leaf(replacements[node])
        else:
            signature = _digest_container(node.tag, [rec(child) for child in node.children])
        memo[node] = signature
        return signature

    return rec(root)


def relation_level(left, right):
    a, j, k, v, i, *_ = left
    b, J, K, V, I, *_ = right
    if a != b:
        return "R6"
    if j != J:
        return "R5"
    if k != K:
        return "R4"
    if v != V:
        return "R3"
    if i != I:
        return "R2"
    return None


def resource_profile(h6, templates, pairs):
    profile = collections.Counter()
    root, entries = _build_merkle(h6)
    for a, j, k, v, i, (p, f), leaf in entries:
        reserved = tuple(p[x] - f[x] for x in range(PN))
        for template in templates:
            source = template["source"]
            child_p = tuple(p[x] + template["dp"][x] for x in range(PN))
            if p[source] <= 0 or min(child_p) < 0:
                continue
            mode = None
            if f[source] > 0:
                mode = "STRICT"
            elif all(child_p[x] >= reserved[x] for x in range(PN)):
                mode = "CROSS"
            if mode is None:
                continue
            child_f = tuple(child_p[x] - reserved[x] for x in range(PN))
            child_sig = _successor_merkle_sig(root, {leaf: (child_p, child_f)})
            profile[(("LIFT", mode, template["index"]), child_sig)] += 1
    for left_index in range(len(entries)):
        left = entries[left_index]
        for right_index in range(left_index + 1, len(entries)):
            right = entries[right_index]
            level = relation_level(left, right)
            if level is None:
                continue
            a, j, k, v, i, (p1, f1), leaf1 = left
            b, J, K, V, I, (p2, f2), leaf2 = right
            for endpoint_left, endpoint_right in pairs:
                if f1[endpoint_left] <= 0 or f2[endpoint_right] <= 0:
                    continue
                next_f1 = list(f1)
                next_f2 = list(f2)
                next_f1[endpoint_left] -= 1
                next_f2[endpoint_right] -= 1
                child_sig = _successor_merkle_sig(
                    root,
                    {
                        leaf1: (p1, tuple(next_f1)),
                        leaf2: (p2, tuple(next_f2)),
                    },
                )
                label = (level, min(endpoint_left, endpoint_right), max(endpoint_left, endpoint_right))
                profile[(label, child_sig)] += 1
    return profile


def resource_label_counts(h6, templates, pairs):
    counts = collections.Counter()
    sites = []
    for a, o5 in enumerate(h6):
        for j, o4 in enumerate(o5):
            for k, o3 in enumerate(o4):
                for v, block in enumerate(o3):
                    for i, state in enumerate(block):
                        sites.append((a, j, k, v, i, state))
    for *_, (p, f) in sites:
        reserved = tuple(p[x] - f[x] for x in range(PN))
        for template in templates:
            source = template["source"]
            child_p = tuple(p[x] + template["dp"][x] for x in range(PN))
            if p[source] <= 0 or min(child_p) < 0:
                continue
            if f[source] > 0:
                counts[("LIFT", "STRICT", template["index"])] += 1
            elif all(child_p[x] >= reserved[x] for x in range(PN)):
                counts[("LIFT", "CROSS", template["index"])] += 1
    for left_index in range(len(sites)):
        for right_index in range(left_index + 1, len(sites)):
            left = sites[left_index]
            right = sites[right_index]
            level = relation_level(left, right)
            if level is None:
                continue
            *_, (_, f1) = left
            *__, (_, f2) = right
            for a, b in pairs:
                if f1[a] > 0 and f2[b] > 0:
                    counts[(level, min(a, b), max(a, b))] += 1
    return counts


def profile_digest(profile):
    payload = [(repr(key), value) for key, value in sorted(profile.items(), key=lambda kv: repr(kv[0]))]
    return hashlib.sha256(json.dumps(payload, separators=(",", ":")).encode()).hexdigest()


def profile_summary(profile):
    return {
        "digest": profile_digest(profile),
        "action_successor_pairs": len(profile),
        "total_action_copies": sum(profile.values()),
    }


def first_profile_separator(left, right):
    keys = sorted(set(left) | set(right), key=repr)
    for key in keys:
        if left.get(key, 0) != right.get(key, 0):
            return {"action_successor": repr(key), "left_count": left.get(key, 0), "right_count": right.get(key, 0)}
    return None


def permute_h6(h6, seed):
    rng = random.Random(seed)
    outer = list(range(len(h6)))
    rng.shuffle(outer)
    result = []
    for aa in outer:
        o5 = h6[aa]
        o4_order = list(range(len(o5)))
        rng.shuffle(o4_order)
        next_o5 = []
        for jj in o4_order:
            o4 = o5[jj]
            o3_order = list(range(len(o4)))
            rng.shuffle(o3_order)
            next_o4 = []
            for kk in o3_order:
                o3 = o4[kk]
                block_order = list(range(len(o3)))
                rng.shuffle(block_order)
                next_o3 = []
                for vv in block_order:
                    block = o3[vv]
                    site_order = list(range(len(block)))
                    rng.shuffle(site_order)
                    next_o3.append(tuple(block[ii] for ii in site_order))
                next_o4.append(tuple(next_o3))
            next_o5.append(tuple(next_o4))
        result.append(tuple(next_o5))
    return tuple(result)


# ---------------------------------------------------------------------------
# Witnesses and external tests
# ---------------------------------------------------------------------------

def topology_sig(owner_count, graph_edges):
    adjacency = [set() for _ in range(owner_count)]
    degrees = [0] * owner_count
    multiplicity = collections.Counter()
    for left, right in graph_edges:
        adjacency[left].add(right)
        adjacency[right].add(left)
        degrees[left] += 1
        degrees[right] += 1
        multiplicity[tuple(sorted((left, right)))] += 1
    triangles = sum(
        1
        for a in range(owner_count)
        for b in range(a + 1, owner_count)
        for c in range(b + 1, owner_count)
        if b in adjacency[a] and c in adjacency[a] and c in adjacency[b]
    )

    def component_count(skip=None):
        seen = set()
        count = 0
        for start in range(owner_count):
            if start == skip or start in seen:
                continue
            count += 1
            stack = [start]
            seen.add(start)
            while stack:
                node = stack.pop()
                for nxt in adjacency[node]:
                    if nxt != skip and nxt not in seen:
                        seen.add(nxt)
                        stack.append(nxt)
        return count

    base_components = component_count()
    articulations = sum(component_count(node) > base_components for node in range(owner_count))
    return {
        "degree_sorted": sorted(degrees),
        "triangles": triangles,
        "articulation_count": articulations,
        "edge_count": len(graph_edges),
        "parallel_multiplicity_sorted": sorted(multiplicity.values()),
    }


def canonical_site_path(o5, endpoint_type, minimum_free=1):
    candidates = []
    for j, o4 in enumerate(o5):
        for k, o3 in enumerate(o4):
            for v, block in enumerate(o3):
                for i, (_, f) in enumerate(block):
                    if f[endpoint_type] >= minimum_free:
                        candidates.append((f[endpoint_type], -j, -k, -v, -i, j, k, v, i))
    return tuple(max(candidates)[-4:]) if candidates else None


def graph_to_edges(graph_edges, path, endpoint_type):
    return tuple(
        sorted(
            (
                left, path[0], path[1], path[2], path[3], endpoint_type,
                right, path[0], path[1], path[2], path[3], endpoint_type,
            )
            for left, right in graph_edges
        )
    )


def first_valid_bridge(proto_ids, prototypes, edges, pairs, left_owners, right_owners):
    used = usage(edges)
    for left in sorted(left_owners):
        for right in sorted(right_owners):
            if left == right:
                continue
            c, d = (left, right) if left < right else (right, left)
            for _, j, k, v, i, _, f1 in all_sites_proto((proto_ids[c],), prototypes):
                for _, J, K, V, I, _, f2 in all_sites_proto((proto_ids[d],), prototypes):
                    for a, b in pairs:
                        edge = (c, j, k, v, i, a, d, J, K, V, I, b)
                        if f1[a] > 0 and f2[b] > 0 and valid_action(proto_ids, prototypes, used, edge):
                            return edge
    return None


def permute_outer_exact(proto_ids, edges, seed):
    rng = random.Random(seed)
    order = list(range(len(proto_ids)))
    rng.shuffle(order)
    new_index = {old: new for new, old in enumerate(order)}
    next_ids = tuple(proto_ids[old] for old in order)
    next_edges = []
    for edge in edges:
        left_old, right_old = edge[0], edge[6]
        left_new, right_new = new_index[left_old], new_index[right_old]
        left_payload = edge[1:6]
        right_payload = edge[7:12]
        if left_new < right_new:
            next_edges.append((left_new, *left_payload, right_new, *right_payload))
        else:
            next_edges.append((right_new, *right_payload, left_new, *left_payload))
    return next_ids, tuple(sorted(next_edges))


def setified_outer_signature(h6):
    return tuple(sorted(set(canon_o5(o5) for o5 in h6)))


def aggregate_component_signature(proto_ids, prototypes, edges):
    inv = component_invariants(proto_ids, prototypes, edges, tuple(range(len(proto_ids))))
    carriers = materialize(proto_ids, prototypes, edges)
    free7 = [0] * PN
    for o5 in carriers:
        for o4 in o5:
            for o3 in o4:
                for block in o3:
                    for _, f in block:
                        for a in range(PN):
                            free7[a] += f[a]
    return {
        key: inv[key]
        for key in ["K5", "m6", "N", "U2", "m3", "m4", "m5", "d", "r", "beta6", "beta_flat", "F", "P", "g"]
    } | {"free7": free7}


def verify_prototype_selection(pool, selection):
    rows = [(row["prototype_id"], list(row["features"])) for row in pool["prototypes"]]
    width = len(rows[0][1])
    mins = [min(row[1][i] for row in rows) for i in range(width)]
    maxs = [max(row[1][i] for row in rows) for i in range(width)]
    normalized = {
        pid: tuple(
            0.0 if maxs[i] == mins[i] else (features[i] - mins[i]) / (maxs[i] - mins[i])
            for i in range(width)
        )
        for pid, features in rows
    }
    centroid = tuple(sum(normalized[pid][i] for pid, _ in rows) / len(rows) for i in range(width))
    first = min((pid for pid, _ in rows), key=lambda pid: (dist(normalized[pid], centroid), pid))
    selected = [first]
    while len(selected) < 6:
        best = None
        for pid, _ in rows:
            if pid in selected:
                continue
            minimum_distance = min(dist(normalized[pid], normalized[other]) for other in selected)
            if (
                best is None
                or minimum_distance > best[0] + 1e-15
                or (abs(minimum_distance - best[0]) <= 1e-15 and pid < best[1])
            ):
                best = (minimum_distance, pid)
        selected.append(best[1])
    return selected == selection["selected_prototype_ids"], selected


def checkpoint_path(lane, rank):
    return CKPT / f"{lane}_m6_{rank}.json.gz"


def save_checkpoint(lane, rank, proto_ids, beam, summary, spec_hash):
    payload = {
        "lane": lane,
        "rank": rank,
        "proto_ids": list(proto_ids),
        "beam": [[list(edge) for edge in state] for state in beam],
        "summary": summary,
        "spec_sha256": spec_hash,
    }
    path = checkpoint_path(lane, rank)
    with gzip.open(path, "wt", encoding="utf-8") as handle:
        json.dump(payload, handle, sort_keys=True, separators=(",", ":"))


def load_latest_checkpoint(lane, proto_ids, max_rank, spec_hash):
    if os.environ.get("O6_PHASE1_REUSE_CHECKPOINTS", "0") != "1":
        return None
    for rank in range(max_rank, -1, -1):
        path = checkpoint_path(lane, rank)
        if not path.exists():
            continue
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            payload = json.load(handle)
        if (
            payload.get("spec_sha256") == spec_hash
            and tuple(payload.get("proto_ids", [])) == tuple(proto_ids)
            and payload.get("rank") == rank
        ):
            beam = [tuple(tuple(edge) for edge in state) for state in payload["beam"]]
            return rank, beam, payload["summary"]
    return None


# ---------------------------------------------------------------------------
# Main audit
# ---------------------------------------------------------------------------

def main():
    started = time.time()
    mark("START")
    ports, pairs = load_rules()
    templates = load_templates()
    pool, prototypes, pin_id = load_prototypes()
    prereg = jload(ROOT / "01_SPEC" / "O6_PHASE1_PREREGISTRATION.json")
    formal_spec = jload(ROOT / "01_SPEC" / "O6_PHASE1_FORMAL_SPEC.json")
    selection = jload(INP / "O6_PHASE1_PROTOTYPE_SELECTION.json")
    phase0 = jload(INP / "O6_PHASE0_REFERENCE_AUDIT_RESULT.json")
    parent_o5 = jload(INP / "O5_PHASE2_GRADUATION_AUDIT_RESULT.json")
    spec_hash = shaj(formal_spec)
    failures = []
    checks = collections.Counter()

    # K01 source and parent integrity.
    phase0_bundle = INP / "Infinity_Grid_Formal_Foundation_v2.6_PHASE0_O6_CARRIER_DERIVATION_COMPLETE_BUNDLE_2026-08-28.zip"
    parent_ok = (
        phase0.get("scientific_status") == "V2_6_PHASE0_O6_CARRIER_DERIVED_WITH_SCOPED_RESOURCE_THEOREM"
        and phase0.get("science_sha256") == PARENT_PHASE0_SCIENCE
        and sha_file(phase0_bundle) == PARENT_PHASE0_BUNDLE_SHA
        and parent_o5.get("status") == "O5_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_5_PHASE2"
        and parent_o5.get("science_sha256") == formal_spec["parent_o5_science_sha256"]
        and prereg.get("parent_phase0_required_status") == phase0.get("scientific_status")
    )
    checks["source_parent_integrity"] = 1 if parent_ok else 0
    if not parent_ok:
        failures.append({"kind": "source_parent_integrity"})

    selection_ok, selected_ids = verify_prototype_selection(pool, selection)
    checks["prototype_selection_verified"] = 1 if selection_ok else 0
    if not selection_ok:
        failures.append({"kind": "prototype_selection", "got": selected_ids})

    # Frozen generation lanes.
    lane_definitions = {
        "HET4": {
            "proto_ids": tuple(selected_ids[:4]),
            "max_m6": int(prereg["lanes"]["HET4"]["max_m6"]),
            "beam_cap": int(prereg["lanes"]["HET4"]["beam_cap"]),
            "reservoir_cap": int(prereg["lanes"]["HET4"]["reservoir_cap"]),
        },
        "HOM6": {
            "proto_ids": tuple([pin_id] * int(prereg["lanes"]["HOM6"]["O5_occurrences"])),
            "max_m6": int(prereg["lanes"]["HOM6"]["max_m6"]),
            "beam_cap": int(prereg["lanes"]["HOM6"]["beam_cap"]),
            "reservoir_cap": int(prereg["lanes"]["HOM6"]["reservoir_cap"]),
        },
    }
    lanes = {}
    saved_states = []
    components = []
    edge_legality_checks = 0
    edge_legality_failures = 0

    for lane_name, lane in lane_definitions.items():
        proto_ids = lane["proto_ids"]
        action_space = action_universe(proto_ids, prototypes, pairs)
        beam = [tuple()]
        rank_summary = [
            {
                "lane": lane_name,
                "m6": 0,
                "beam_states": 1,
                "reservoir_states": 1,
                "enabled_action_copies": len(action_space),
                "nontrivial_components": 0,
                "invariant_failures": 0,
                "legality_failures": 0,
            }
        ]
        start_rank = 0
        checkpoint = load_latest_checkpoint(lane_name, proto_ids, lane["max_m6"], spec_hash)
        if checkpoint is not None:
            start_rank, beam, rank_summary = checkpoint
        if start_rank == 0:
            saved_states.append(
                {"lane": lane_name, "m6": 0, "proto_ids": list(proto_ids), "edges": [], "digest": state_digest(tuple())}
            )
            save_checkpoint(lane_name, 0, proto_ids, beam, rank_summary, spec_hash)

        for rank in range(start_rank + 1, lane["max_m6"] + 1):
            reservoir, enabled = reservoir_successors(
                beam, proto_ids, prototypes, action_space, lane["reservoir_cap"]
            )
            beam = farthest(reservoir, proto_ids, prototypes, lane["beam_cap"])
            nontrivial = 0
            invariant_bad = 0
            legality_bad = 0
            for edges in beam:
                exact_failures = validate_exact_state(proto_ids, prototypes, edges, pairs)
                edge_legality_checks += len(edges)
                edge_legality_failures += len(exact_failures)
                legality_bad += len(exact_failures)
                if exact_failures and len(failures) < 30:
                    failures.append(
                        {
                            "kind": "exact_state_legality",
                            "lane": lane_name,
                            "m6": rank,
                            "digest": state_digest(edges),
                            "details": exact_failures[:5],
                        }
                    )
                for component in graph_components(len(proto_ids), edges):
                    if len(component) < 2:
                        continue
                    nontrivial += 1
                    invariants = component_invariants(proto_ids, prototypes, edges, component)
                    if not invariants["ok"]:
                        invariant_bad += 1
                        if len(failures) < 30:
                            failures.append(
                                {
                                    "kind": "component_invariant",
                                    "lane": lane_name,
                                    "m6": rank,
                                    "digest": state_digest(edges),
                                    "component": list(component),
                                    "invariants": invariants,
                                }
                            )
                    components.append((lane_name, proto_ids, edges, component))
                saved_states.append(
                    {
                        "lane": lane_name,
                        "m6": rank,
                        "proto_ids": list(proto_ids),
                        "edges": [list(edge) for edge in edges],
                        "digest": state_digest(edges),
                    }
                )
            rank_summary.append(
                {
                    "lane": lane_name,
                    "m6": rank,
                    "beam_states": len(beam),
                    "reservoir_states": len(reservoir),
                    "enabled_action_copies": enabled,
                    "nontrivial_components": nontrivial,
                    "invariant_failures": invariant_bad,
                    "legality_failures": legality_bad,
                }
            )
            save_checkpoint(lane_name, rank, proto_ids, beam, rank_summary, spec_hash)
        lanes[lane_name] = {
            "action_universe": len(action_space),
            "final_beam": len(beam),
            "rank_summary": rank_summary,
        }

    checks["edge_legality_checks"] = edge_legality_checks
    checks["edge_legality_failures"] = edge_legality_failures
    if edge_legality_failures:
        failures.append({"kind": "edge_legality_total", "failures": edge_legality_failures})

    mark("GENERATION_COMPLETE")
    # K09 same-R6 / different-E6 topology witness.
    self_types = sorted(a for a, b in pairs if a == b)
    base = prototypes[pin_id]["o5"]
    topology_choice = None
    for endpoint_type in self_types:
        path = canonical_site_path(base, endpoint_type, minimum_free=4)
        if path is not None:
            topology_choice = (endpoint_type, path)
            break
    if topology_choice is None:
        failures.append({"kind": "hidden_topology_no_endpoint"})
        hidden_topology = {"found": False}
    else:
        endpoint_type, path = topology_choice
        graph_a = ((0, 4), (0, 5), (1, 2), (1, 4), (2, 4), (3, 4))
        graph_b = ((0, 2), (0, 3), (0, 4), (0, 5), (1, 2), (1, 3))
        proto_ids = tuple([pin_id] * 6)
        edges_a = graph_to_edges(graph_a, path, endpoint_type)
        edges_b = graph_to_edges(graph_b, path, endpoint_type)
        h_a = materialize(proto_ids, prototypes, edges_a)
        h_b = materialize(proto_ids, prototypes, edges_b)
        profile_a = resource_profile(h_a, templates, pairs)
        profile_b = resource_profile(h_b, templates, pairs)
        hidden_topology = {
            "found": True,
            "same_R6_resource_skin": canon_r6(h_a) == canon_r6(h_b),
            "exact_topology_distinct": topology_sig(6, graph_a) != topology_sig(6, graph_b),
            "graph_A": [list(edge) for edge in graph_a],
            "graph_B": [list(edge) for edge in graph_b],
            "topology_A": topology_sig(6, graph_a),
            "topology_B": topology_sig(6, graph_b),
            "source_prototype": pin_id,
            "reservation_path": list(path),
            "reservation_type": endpoint_type,
            "resource_profile_A": profile_summary(profile_a),
            "resource_profile_B": profile_summary(profile_b),
            "resource_profile_equal": profile_a == profile_b,
        }
        if not (
            hidden_topology["same_R6_resource_skin"]
            and hidden_topology["exact_topology_distinct"]
            and hidden_topology["resource_profile_equal"]
        ):
            failures.append({"kind": "hidden_topology_collision", "witness": hidden_topology})
    jdump(OUT / "O6_PHASE1_HIDDEN_TOPOLOGY_WITNESS.json", hidden_topology)
    mark("HIDDEN_TOPOLOGY_COMPLETE")

    # K04 hierarchical relabeling invariance of R6 and its direct profile.
    relabel_checks = int(formal_spec["hierarchical_relabeling_checks"])
    relabel_mismatches = 0
    if hidden_topology.get("found"):
        reference_h = materialize(tuple([pin_id] * 6), prototypes, graph_to_edges(
            tuple(tuple(x) for x in hidden_topology["graph_A"]),
            tuple(hidden_topology["reservation_path"]),
            hidden_topology["reservation_type"],
        ))
        reference_profile = resource_profile(reference_h, templates, pairs)
        reference_skin = canon_r6(reference_h)
        for seed in range(relabel_checks):
            permuted = permute_h6(reference_h, 2606100 + seed)
            if canon_r6(permuted) != reference_skin or resource_profile(permuted, templates, pairs) != reference_profile:
                relabel_mismatches += 1
    mark("RELABELING_COMPLETE")
    checks["hierarchical_relabeling_checks"] = relabel_checks
    checks["hierarchical_relabeling_mismatches"] = relabel_mismatches
    if relabel_mismatches:
        failures.append({"kind": "hierarchical_relabeling", "mismatches": relabel_mismatches})

    # K05 and K06 inherited Phase-0 witnesses.
    inherited_outer = (
        phase0.get("checks", {}).get("outer_o5_grouping_separator") == 1
        and phase0.get("outer_grouping_witness", {}).get("same_flattened_R5_resource_state") is True
    )
    typed = jload(INP / "PINNED_TYPED_RESERVATION_PLACEMENT_WITNESS.json")
    wa, wb = typed["a"], typed["b"]
    inherited_typed = (
        phase0.get("checks", {}).get("typed_reservation_separator") == 1
        and wa["state"][:7] == wb["state"][:7]
        and sum(wa["reservation"]) == sum(wb["reservation"])
        and wa["reservation"] != wb["reservation"]
        and typed["separator_transition"] == 28
        and 28 in typed["guarded_only_a"]
        and 28 not in typed["guarded_only_b"]
    )
    checks["outer_grouping_witness_replayed"] = 1 if inherited_outer else 0
    checks["typed_reservation_witness_replayed"] = 1 if inherited_typed else 0
    if not inherited_outer:
        failures.append({"kind": "outer_grouping_witness_replay"})
    if not inherited_typed:
        failures.append({"kind": "typed_reservation_witness_replay"})

    # K07 setification/multiplicity ablation.
    multiplicity_witness = {"found": False}
    mult_choice = None
    for endpoint_type in self_types:
        path = canonical_site_path(base, endpoint_type, minimum_free=2)
        if path is not None:
            mult_choice = (endpoint_type, path)
            break
    if mult_choice is not None:
        endpoint_type, path = mult_choice
        ids_a = (pin_id, pin_id)
        ids_b = (pin_id, pin_id, pin_id)
        graph_a = ((0, 1), (0, 1))
        graph_b = ((0, 1), (1, 2), (0, 2))
        edges_a = graph_to_edges(graph_a, path, endpoint_type)
        edges_b = graph_to_edges(graph_b, path, endpoint_type)
        h_a = materialize(ids_a, prototypes, edges_a)
        h_b = materialize(ids_b, prototypes, edges_b)
        profile_a = resource_profile(h_a, templates, pairs)
        profile_b = resource_profile(h_b, templates, pairs)
        multiplicity_witness = {
            "found": True,
            "setified_outer_signature_equal": setified_outer_signature(h_a) == setified_outer_signature(h_b),
            "full_R6_bags_distinct": canon_r6(h_a) != canon_r6(h_b),
            "state_A": {"O5_occurrences": 2, "E6_edges": [list(x) for x in graph_a]},
            "state_B": {"O5_occurrences": 3, "E6_edges": [list(x) for x in graph_b]},
            "reservation_path": list(path),
            "reservation_type": endpoint_type,
            "resource_profile_A": profile_summary(profile_a),
            "resource_profile_B": profile_summary(profile_b),
            "resource_profiles_distinct": profile_a != profile_b,
            "separator": first_profile_separator(profile_a, profile_b),
        }
    if not (
        multiplicity_witness.get("found")
        and multiplicity_witness.get("setified_outer_signature_equal")
        and multiplicity_witness.get("resource_profiles_distinct")
    ):
        failures.append({"kind": "setification_multiplicity", "witness": multiplicity_witness})
    jdump(OUT / "O6_PHASE1_SETIFICATION_MULTIPLICITY_WITNESS.json", multiplicity_witness)
    mark("SETIFICATION_COMPLETE")

    # K08 aggregate-collapse ablation: deterministic search over pre-existing
    # aggregate-collision groups, without outcome-adaptive panel extension.
    aggregate_fields = ["K4", "m5", "beta5", "N", "U2", "m3", "m4", "d", "r", "beta_flat5", "total_free"]
    aggregate_groups = collections.defaultdict(list)
    for raw in pool["prototypes"]:
        acc = raw["accounting"]
        signature = tuple(acc[field] for field in aggregate_fields) + tuple(acc["free7"])
        aggregate_groups[signature].append(raw["prototype_id"])
    candidates = [
        (signature, sorted(ids))
        for signature, ids in aggregate_groups.items()
        if len(ids) >= 2
    ]
    candidates.sort(key=lambda item: (item[0], item[1]))
    aggregate_witness = {"found": False, "candidate_pairs_examined": 0}
    for signature, ids in candidates:
        for pid_a, pid_b in itertools.combinations(ids, 2):
            for endpoint_type in self_types:
                path_a = canonical_site_path(prototypes[pid_a]["o5"], endpoint_type, minimum_free=1)
                path_b = canonical_site_path(prototypes[pid_b]["o5"], endpoint_type, minimum_free=1)
                if path_a is None or path_b is None:
                    continue
                aggregate_witness["candidate_pairs_examined"] += 1
                ids_a = (pid_a, pid_a)
                ids_b = (pid_b, pid_b)
                edge_a = (0, *path_a, endpoint_type, 1, *path_a, endpoint_type)
                edge_b = (0, *path_b, endpoint_type, 1, *path_b, endpoint_type)
                h_a = materialize(ids_a, prototypes, (edge_a,))
                h_b = materialize(ids_b, prototypes, (edge_b,))
                aggregate_a = aggregate_component_signature(ids_a, prototypes, (edge_a,))
                aggregate_b = aggregate_component_signature(ids_b, prototypes, (edge_b,))
                if aggregate_a != aggregate_b:
                    continue
                labels_a = resource_label_counts(h_a, templates, pairs)
                labels_b = resource_label_counts(h_b, templates, pairs)
                if labels_a == labels_b:
                    continue
                profile_a = resource_profile(h_a, templates, pairs)
                profile_b = resource_profile(h_b, templates, pairs)
                if profile_a == profile_b:
                    continue
                aggregate_witness = {
                    "found": True,
                    "candidate_pairs_examined": aggregate_witness["candidate_pairs_examined"],
                    "prototype_A": pid_a,
                    "prototype_B": pid_b,
                    "shared_parent_aggregate_signature": list(signature),
                    "O6_aggregate_signature_A": aggregate_a,
                    "O6_aggregate_signature_B": aggregate_b,
                    "reservation_type": endpoint_type,
                    "path_A": list(path_a),
                    "path_B": list(path_b),
                    "resource_label_counts_A_sha256": shaj([(repr(k), v) for k, v in sorted(labels_a.items(), key=lambda kv: repr(kv[0]))]),
                    "resource_label_counts_B_sha256": shaj([(repr(k), v) for k, v in sorted(labels_b.items(), key=lambda kv: repr(kv[0]))]),
                    "resource_profile_A": profile_summary(profile_a),
                    "resource_profile_B": profile_summary(profile_b),
                    "separator": first_profile_separator(profile_a, profile_b),
                }
                break
            if aggregate_witness.get("found"):
                break
        if aggregate_witness.get("found"):
            break
    if not aggregate_witness.get("found"):
        failures.append({"kind": "aggregate_collapse_no_separator", "search": aggregate_witness})
    jdump(OUT / "O6_PHASE1_AGGREGATE_COLLAPSE_WITNESS.json", aggregate_witness)
    mark("AGGREGATE_COMPLETE")

    # K05 generated-family R6 factorisation collisions.
    normalized_components = []
    collision_groups = collections.defaultdict(list)
    for lane_name, proto_ids, edges, component in sorted(
        components, key=lambda item: (item[0], state_digest(item[2]), item[3])
    ):
        next_ids, next_edges = normalize_component(proto_ids, edges, component)
        h6 = materialize(next_ids, prototypes, next_edges)
        key = r6_digest(h6)
        normalized_components.append((next_ids, next_edges, key))
        collision_groups[key].append((next_ids, next_edges))
    factorization_checks = 0
    factorization_mismatches = 0
    repeated_groups = [
        (key, values) for key, values in sorted(collision_groups.items()) if len(values) >= 2
    ]
    for key, values in repeated_groups[: int(formal_spec["generated_factorization_group_cap"])]:
        ids_a, edges_a = values[0]
        ids_b, edges_b = values[1]
        h_a = materialize(ids_a, prototypes, edges_a)
        h_b = materialize(ids_b, prototypes, edges_b)
        if canon_r6(h_a) != canon_r6(h_b):
            continue
        factorization_checks += 1
        if resource_profile(h_a, templates, pairs) != resource_profile(h_b, templates, pairs):
            factorization_mismatches += 1
    mark("GENERATED_FACTORIZATION_COMPLETE")
    checks["generated_equal_R6_groups_found"] = len(repeated_groups)
    checks["generated_factorization_checks"] = factorization_checks
    checks["generated_factorization_mismatches"] = factorization_mismatches
    if factorization_mismatches:
        failures.append({"kind": "generated_R6_factorization", "mismatches": factorization_mismatches})

    # K10 bounded external closure and representative independence.
    closure_o5_pass = 0
    closure_o6_pass = 0
    closure_failures = 0
    closure_relabel_checks = 0
    closure_relabel_mismatches = 0
    for index, (proto_ids, edges, _) in enumerate(normalized_components[:128]):
        next_ids = proto_ids + (selected_ids[0],)
        bridge = first_valid_bridge(
            next_ids, prototypes, edges, pairs, range(len(proto_ids)), [len(proto_ids)]
        )
        if bridge is None:
            closure_failures += 1
            continue
        next_edges = add_edge(edges, bridge)
        inv = component_invariants(next_ids, prototypes, next_edges, tuple(range(len(next_ids))))
        if inv["ok"]:
            closure_o5_pass += 1
        else:
            closure_failures += 1
        if index < 16:
            perm_ids, perm_edges = permute_outer_exact(next_ids, next_edges, 2606200 + index)
            closure_relabel_checks += 1
            if canon_r6(materialize(next_ids, prototypes, next_edges)) != canon_r6(materialize(perm_ids, prototypes, perm_edges)):
                closure_relabel_mismatches += 1
    for index in range(min(64, len(normalized_components) // 2)):
        ids_a, edges_a, _ = normalized_components[2 * index]
        ids_b, edges_b, _ = normalized_components[2 * index + 1]
        offset = len(ids_a)
        next_ids = ids_a + ids_b
        shifted_b = tuple(
            (
                edge[0] + offset, edge[1], edge[2], edge[3], edge[4], edge[5],
                edge[6] + offset, edge[7], edge[8], edge[9], edge[10], edge[11],
            )
            for edge in edges_b
        )
        combined_edges = tuple(sorted(edges_a + shifted_b))
        bridge = first_valid_bridge(
            next_ids, prototypes, combined_edges, pairs, range(offset), range(offset, len(next_ids))
        )
        if bridge is None:
            closure_failures += 1
            continue
        next_edges = add_edge(combined_edges, bridge)
        inv = component_invariants(next_ids, prototypes, next_edges, tuple(range(len(next_ids))))
        if inv["ok"]:
            closure_o6_pass += 1
        else:
            closure_failures += 1
        if index < 16:
            perm_ids, perm_edges = permute_outer_exact(next_ids, next_edges, 2606300 + index)
            closure_relabel_checks += 1
            if canon_r6(materialize(next_ids, prototypes, next_edges)) != canon_r6(materialize(perm_ids, prototypes, perm_edges)):
                closure_relabel_mismatches += 1
    if closure_failures or closure_relabel_mismatches:
        failures.append(
            {
                "kind": "external_closure",
                "failures": closure_failures,
                "relabel_mismatches": closure_relabel_mismatches,
            }
        )

    mark("EXTERNAL_CLOSURE_COMPLETE")
    # K11 fixed-final-relation-set construction-order independence.
    order_checks = 0
    order_failures = 0
    candidates_for_order = [
        (tuple(state["proto_ids"]), tuple(tuple(edge) for edge in state["edges"]))
        for state in saved_states
        if state["m6"] >= 3
    ]
    for proto_ids, edges in candidates_for_order[:32]:
        sample = edges[: min(4, len(edges))]
        finals = []
        for permutation in itertools.permutations(sample):
            current = tuple()
            valid = True
            for edge in permutation:
                if not valid_action(proto_ids, prototypes, usage(current), edge):
                    valid = False
                    break
                current = add_edge(current, edge)
            if valid:
                finals.append(current)
        if finals:
            order_checks += 1
            if len(set(finals)) != 1:
                order_failures += 1
    if order_failures:
        failures.append({"kind": "order_independence", "failures": order_failures})

    mark("ORDER_INDEPENDENCE_COMPLETE")
    # K12 no-new-read-field contract. Exact E6 topology is not an argument to
    # resource_profile; the same-R6/different-topology witness and relabeling
    # checks are the executable falsification tests for this scoped claim.
    profile_parameters = list(inspect.signature(resource_profile).parameters)
    no_new_read_field = (
        profile_parameters == ["h6", "templates", "pairs"]
        and hidden_topology.get("resource_profile_equal") is True
        and relabel_mismatches == 0
    )
    checks["no_new_read_field_contract"] = 1 if no_new_read_field else 0
    if not no_new_read_field:
        failures.append({"kind": "no_new_read_field_contract", "parameters": profile_parameters})

    # Write principal machine-readable outputs.
    jdump(OUT / "O6_PHASE1_GENERATED_SELECTED_STATES.json", {"states": saved_states})
    with (OUT / "O6_PHASE1_GENERATION_SUMMARY.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = [
            "lane", "m6", "beam_states", "reservoir_states", "enabled_action_copies",
            "nontrivial_components", "invariant_failures", "legality_failures",
        ]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for lane in lanes.values():
            for row in lane["rank_summary"]:
                writer.writerow({key: row.get(key, 0) for key in fields})

    result = {
        "program": "IG_V26_PHASE1_BOUNDED_O6_GENERATION_ADVERSARIAL_AUDIT",
        "status": "PASS" if not failures else "FAIL",
        "scientific_status": "V2_6_PHASE1_BOUNDED_O6_GENERATION_ADVERSARIAL_PASS" if not failures else "V2_6_PHASE1_FAIL_CLOSED",
        "graduation": "NOT_ATTEMPTED_IN_PHASE1",
        "parent_phase0_science_sha256": phase0.get("science_sha256"),
        "parent_phase0_bundle_sha256": sha_file(phase0_bundle),
        "prototype_selection_verified": selection_ok,
        "selected_prototypes": selected_ids,
        "lanes": lanes,
        "selected_state_records": len(saved_states),
        "connected_component_occurrences_checked": len(components),
        "checks": dict(checks),
        "hidden_topology_collision": hidden_topology,
        "hierarchical_relabeling": {"checks": relabel_checks, "mismatches": relabel_mismatches},
        "outer_grouping_witness_replayed": inherited_outer,
        "typed_reservation_witness_replayed": inherited_typed,
        "setification_multiplicity_witness": multiplicity_witness,
        "aggregate_collapse_witness": aggregate_witness,
        "generated_R6_factorization": {
            "repeated_equal_R6_groups_found": len(repeated_groups),
            "checks": factorization_checks,
            "mismatches": factorization_mismatches,
        },
        "external_closure": {
            "O6xO5_passes": closure_o5_pass,
            "O6xO6_passes": closure_o6_pass,
            "failures": closure_failures,
            "representative_relabel_checks": closure_relabel_checks,
            "representative_relabel_mismatches": closure_relabel_mismatches,
        },
        "order_independence": {"checks": order_checks, "failures": order_failures},
        "read_write_contract": {
            "resource_profile_parameters": profile_parameters,
            "reads": ["hierarchical ownership", "sitewise p", "sitewise f", "rank templates", "bridge matrix"],
            "does_not_read": ["exact E6 topology", "T", "ancestry", "reservation provenance"],
            "pass": no_new_read_field,
        },
        "failure_count": len(failures),
        "failures": failures,
        "conclusion": (
            "The Phase-0 exact O6 carrier and provisional R6^0 resource skin survive the frozen bounded generated/adversarial programme. Same R6^0 can hide distinct connected E6 topology while preserving the frozen multiplicity-aware resource action profile. Outer O5 ownership, bag multiplicity, sitewise typed placement, and local organization remain operationally necessary under the tested observers. O6 remains ungraduated until a separate Phase-2 classification audit."
            if not failures
            else "Phase 1 failed closed. Do not proceed to O6 graduation."
        ),
        "nonclaims": prereg["phase1_nonclaim"],
        "next_phase": "v2.6 Phase 2 O6 graduation/classification audit under separately frozen gates" if not failures else "repair or retract before any Phase-2 attempt",
    }
    result["science_sha256"] = shaj({key: value for key, value in result.items() if key != "science_sha256"})
    jdump(OUT / "O6_PHASE1_AUDIT_RESULT.json", result)
    runtime_record = {
        "program": result["program"],
        "runtime_seconds": round(time.time() - started, 6),
        "science_sha256": result["science_sha256"],
    }
    jdump(ROOT / "07_PROVENANCE" / "RUNTIME.json", runtime_record)
    mark("RESULT_WRITTEN")
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
