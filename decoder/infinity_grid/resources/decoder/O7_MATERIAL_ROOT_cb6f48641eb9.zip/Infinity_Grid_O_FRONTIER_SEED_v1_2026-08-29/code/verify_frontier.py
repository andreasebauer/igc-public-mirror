#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys
R=Path(__file__).resolve().parent.parent
TARGET=(sys.argv[1] if len(sys.argv)>1 else 'ALL').upper()
MAP={
 'O7':('authority/O7_GRADUATION_RESULT.json','status','O7_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_7_PHASE2','a3e0bed91b9e68edd4d7c9f508587d6801f9651b0485c6ce40e8ca284ffc2d90'),
 'O7_ADAPTER':('authority/O7_ADAPTER_AUDIT_RESULT.json','status','ADAPTER_PASS','3a81c8fac30eb37359b366bc7d2eb2f298440f112ceea95f84d40c3832bc139d'),
 'O7_POST_STRUCTURAL':('authority/POST_O7_STRUCTURAL_AUDIT_RECONCILED_RESULT.json','status','PASS','55dffae9d45032b47c6f3f16dd19c998b39861a1ab342c99abfc6a53fb223ebb'),
 'O7_TOPOLOGY_READ':('authority/O7_TOPOLOGY_AWARE_READ_PROBE_RESULT.json','operational_read_classification','TOPOLOGY_REMAINS_HIDDEN_UNDER_O7_ACTIONS','51079cc1598aa5d3d1e80c998dafbd855d14c26667661b87ef138e1730058303'),
 'O8_BP0':('authority/O8_BP0_RESULT.json','outcome','O8_EXISTS_GRRL_REPEAT_STOP','20414149d2f78610fb20b348323715618681336ba534856b309994084bcfc7ca'),
}
def shaf(p):
 h=hashlib.sha256();
 with p.open('rb') as f:
  for c in iter(lambda:f.read(1<<20),b''):h.update(c)
 return h.hexdigest()
checks=[]; ok=True
for key,(rel,field,exp,science) in MAP.items():
 if TARGET not in ('ALL',key):continue
 p=R/rel
 try:
  d=json.loads(p.read_text()); got=d.get(field); sci=d.get('science_sha256')
  c={'target':key,'file':rel,'field':field,'expected':exp,'got':got,'science_expected':science,'science_got':sci,'status':'PASS' if got==exp and sci==science else 'FAIL'}
 except Exception as e:c={'target':key,'file':rel,'status':'FAIL','error':repr(e)}
 checks.append(c);ok &= c['status']=='PASS'
# Cross-pins that define the frontier.
try:
 o8=json.loads((R/'authority/O8_BP0_RESULT.json').read_text());o7=json.loads((R/'authority/O7_TOPOLOGY_AWARE_READ_PROBE_RESULT.json').read_text())
 cp=(o8['parent_O7_science_sha256']==MAP['O7'][3] and o8['O7_read_probe_science_sha256']==MAP['O7_TOPOLOGY_READ'][3] and o8['data_budget_used']['broad_census']==0 and not o8['emergent_read_gate']['R3_new_operational_read_found'])
 checks.append({'target':'FRONTIER_CROSS_PINS','status':'PASS' if cp else 'FAIL'});ok &= cp
except Exception as e:checks.append({'target':'FRONTIER_CROSS_PINS','status':'FAIL','error':repr(e)});ok=False
out={'schema':'IG_PHASE7_FRONTIER_VERIFICATION_V1','target':TARGET,'status':'PASS' if ok else 'FAIL','checks':checks}
(R/'PHASE7_FRONTIER_VERIFICATION.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps(out,indent=2,sort_keys=True));sys.exit(0 if ok else 2)
