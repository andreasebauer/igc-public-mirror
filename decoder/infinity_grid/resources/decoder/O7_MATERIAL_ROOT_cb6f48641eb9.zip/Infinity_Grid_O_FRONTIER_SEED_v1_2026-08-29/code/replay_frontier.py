#!/usr/bin/env python3
from pathlib import Path
import zipfile,shutil,subprocess,sys,json,os
R=Path(__file__).resolve().parent.parent
MODE=(sys.argv[1] if len(sys.argv)>1 else 'O7_READ').upper()
RT=R/'_frontier_runtime'; OUT=R/'_frontier_replay_results'
shutil.rmtree(RT,ignore_errors=True);shutil.rmtree(OUT,ignore_errors=True);RT.mkdir();OUT.mkdir()
zp=R/'replay/Infinity_Grid_O7_COMPACT_REPLAY_ROOT_v1_2026-08-29.zip'
with zipfile.ZipFile(zp) as z:z.extractall(RT)
tops=[p for p in RT.iterdir() if p.is_dir()]
if len(tops)!=1: raise SystemExit(f'bad nested replay root: {tops}')
rr=tops[0]
if MODE in ('O7_READ','O7_TOPOLOGY_READ'):
 cmd=[sys.executable,'-m','infinity_grid.cli','frontier','o7-read-probe','--o7-graduation-root',str(R/'graduation_compact'),'--post-o7-root',str(R/'authority'),'--o7-runtime-root',str(rr),'--output',str(OUT)]
 auth=R/'authority/O7_TOPOLOGY_AWARE_READ_PROBE_RESULT.json'; fresh=OUT/'O7_TOPOLOGY_AWARE_READ_PROBE_RESULT.json'
elif MODE=='O8_BP0':
 cmd=[sys.executable,'-m','infinity_grid.cli','frontier','o8-bp0','--o7-graduation-root',str(R/'graduation_compact'),'--o7-runtime-root',str(rr),'--o7-read-probe',str(R/'authority/O7_TOPOLOGY_AWARE_READ_PROBE_RESULT.json'),'--output',str(OUT)]
 auth=R/'authority/O8_BP0_RESULT.json'; fresh=OUT/'O8_BP0_RESULT.json'
else: raise SystemExit('mode must be O7_READ or O8_BP0')
p=subprocess.run(cmd,cwd=R,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
try:a=json.loads(auth.read_text());f=json.loads(fresh.read_text()); match=a.get('science_sha256')==f.get('science_sha256') and f.get('status')=='PASS'
except Exception as e:a={};f={};match=False
res={'schema':'IG_PHASE7_FRONTIER_REPLAY_RESULT_V1','mode':MODE,'status':'PASS' if p.returncode==0 and match else 'FAIL','returncode':p.returncode,'authority_science_sha256':a.get('science_sha256'),'replay_science_sha256':f.get('science_sha256'),'science_match':match,'stdout_tail':p.stdout[-2000:],'stderr_tail':p.stderr[-2000:]}
(R/'PHASE7_FRONTIER_REPLAY_RESULT.json').write_text(json.dumps(res,indent=2,sort_keys=True)+'\n');print(json.dumps(res,indent=2,sort_keys=True));sys.exit(0 if res['status']=='PASS' else 2)
