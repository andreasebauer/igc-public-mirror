#!/usr/bin/env python3
import hashlib,json,pathlib,sys
R=pathlib.Path(__file__).resolve().parent
fails=[]
manifest=R/'06_PROVENANCE/SHA256SUMS.txt'
for line in manifest.read_text().splitlines():
 if not line.strip(): continue
 sha,rel=line.split('  ',1); p=R/rel
 if not p.exists(): fails.append(['missing',rel]); continue
 h=hashlib.sha256(p.read_bytes()).hexdigest()
 if h!=sha: fails.append(['hash',rel,sha,h])
res=json.loads((R/'02_RESULTS/O7_PHASE2_GRADUATION_AUDIT_RESULT.json').read_text())
if res.get('status')!='O7_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_7_PHASE2': fails.append(['status',res.get('status')])
for k,v in res.get('criteria',{}).items():
 if v.get('status')!='PASS': fails.append(['gate',k,v.get('status')])
cl=json.loads((R/'02_RESULTS/O7_SYMBOLIC_TRANSITION_CLOSURE_RESULT.json').read_text())
if cl.get('status')!='PASS': fails.append(['closure',cl.get('status')])
re=json.loads((R/'02_RESULTS/O7_GRADUATION_INDEPENDENT_GENERATED_FAMILY_RECHECK.json').read_text())
if re.get('status')!='PASS' or re.get('failure_count')!=0: fails.append(['recheck',re.get('status'),re.get('failure_count')])
print(json.dumps({'status':'PASS' if not fails else 'FAIL','files_checked':len(manifest.read_text().splitlines()),'failures':fails},indent=2))
sys.exit(0 if not fails else 2)
