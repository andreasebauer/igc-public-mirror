#!/usr/bin/env python3
from __future__ import annotations

import bisect, collections, csv, hashlib, importlib.util, itertools, json, math, multiprocessing as mp, os, random, struct, sys, time
try:
 import numpy as np
 from numba import njit
except Exception:
 np=None; njit=None
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(os.environ.get('OSCOUT_DATA_ROOT', str(Path(__file__).resolve().parent.parent))).resolve()
FROZEN = ROOT/'01_FROZEN'; CODE=ROOT/'02_CODE'; RESULTS=ROOT/'03_RESULTS'; CKPT=ROOT/'04_CHECKPOINTS'; LOGS=ROOT/'05_LOGS'; PROV=ROOT/'06_PROVENANCE'; CACHE=ROOT/'07_SOURCE_CACHE'; SURV=ROOT/'08_SURVIVORS'
PREREG_ROOT = CACHE/'prereg'/'Infinity_Grid_OScout_v0.1_O7_LIVE_RECONNAISSANCE_PREREGISTRATION_2026-08-28'
O6P1_ROOT = CACHE/'o6p1'/'Infinity_Grid_Formal_Foundation_v2.6_PHASE1_BOUNDED_O6_GENERATION_ADVERSARIAL_2026-08-28'
O6P2_ROOT = CACHE/'o6p2'/'Infinity_Grid_Formal_Foundation_v2.6_PHASE2_O6_GRADUATION_CLASSIFICATION_2026-08-28'
SPEC_PATH = PREREG_ROOT/'02_SPEC'/'OSCOUT_O7_LIVE_PREREGISTRATION_v0.1.json'
CORR_PATH = FROZEN/'OSCOUT_O7_PREGEN_EXECUTION_CONFORMANCE_CORRECTION_v0.1.2.json'
PROTO_PATH = PREREG_ROOT/'04_PROTOTYPES'/'OSCOUT_O7_SELECTED_O6_PROTOTYPES.json'
TWINS_PATH = PREREG_ROOT/'04_PROTOTYPES'/'OSCOUT_O7_O6_TOPOLOGY_TWINS.json'
O6MOD_PATH = O6P1_ROOT/'03_CODE'/'o6_phase1_bounded_generation_audit.py'

EXPECTED = {
 'prereg_science':'1459e670df72028d4f9978549d2da0f179029079ae0769953eddcd19b426bbd8',
 'correction_science':'e1ce490a8bbe29cc9d818a601539a5010f1ab9ada6a076b3e480c0b0a643741f',
 'o6_science':'7b9e3ec0fbabcdb0fa46c2d5d153ac186cdd2d2343275a407e82b6fd14d9da37',
 'o6_bundle':'1e0934060973a98cd4c9d47e7d1e42819ed354291312980586751fba64770545',
 'instrument_bundle':'0ff8428fadd61d3525ad5cca3d4d5e75d4982c3a16cc484ce340c4fb6d7a61da',
 'prereg_bundle':'1b23d59eab07190e2b61deac8b8289f6d69ff66120e0a3f83ff2cdff3ed7e4a4',
 'shadow_bundle':'b5216900fe7a5411e497c57706e9f00ee9cce19e3a92e911c07065b0507977c2',
}
BUNDLE_NAMES = {
 'o6_bundle':'Infinity_Grid_Formal_Foundation_v2.6_PHASE2_O6_GRADUATION_CLASSIFICATION_COMPLETE_BUNDLE_2026-08-28.zip',
 'instrument_bundle':'Infinity_Grid_OScout_v0.1_IMPLEMENTATION_SELF_TEST_COMPLETE_BUNDLE_2026-08-28.zip',
 'prereg_bundle':'Infinity_Grid_OScout_v0.1_O7_LIVE_RECONNAISSANCE_PREREGISTRATION_COMPLETE_BUNDLE_2026-08-28.zip',
 'shadow_bundle':'Infinity_Grid_OScout_v0.1.1_O7_DECISION_READINESS_SHADOW_LANE_ADDENDUM_COMPLETE_BUNDLE_2026-08-28.zip',
}
PN=7
STATE_HASH_PREFIX=b'IG-E7-STATE-v1|'
ENGINE_VERSION='OSCOUT_EXECUTION_ENGINE_v0.2.4_C04_CONTEXT_REPAIR'
ENGINE_SCIENCE_SEMANTICS='UNCHANGED_FROM_v0.1.3'


def jload(p:Path): return json.loads(p.read_text(encoding='utf-8'))
def sha_file(p:Path):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''): h.update(b)
 return h.hexdigest()
def shaj(v): return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def atomic_json(p:Path,v):
 p.parent.mkdir(parents=True,exist_ok=True); tmp=p.with_suffix(p.suffix+'.tmp')
 tmp.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n',encoding='utf-8'); os.replace(tmp,p)
def status(msg):
 LOGS.mkdir(parents=True,exist_ok=True)
 with (LOGS/'STATUS.log').open('a',encoding='utf-8') as f: f.write(f'{time.strftime("%Y-%m-%dT%H:%M:%S%z")}\t{msg}\n'); f.flush()

def import_o6():
 spec=importlib.util.spec_from_file_location('ig_o6p1',O6MOD_PATH); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
O6=None

def spec_hash(): return jload(SPEC_PATH)['science_sha256']
def correction_hash(): return jload(CORR_PATH)['correction_science_sha256']

def checkpoint(stage:str, result:Any, started:float, inputs=None):
 core={'schema':'OSCOUT_O7_CHECKPOINT_V0_1_2','stage':stage,'prereg_science_sha256':EXPECTED['prereg_science'],'correction_science_sha256':EXPECTED['correction_science'],'parent_o6_science_sha256':EXPECTED['o6_science'],'inputs':inputs or {},'result':result,'runtime_seconds':round(time.time()-started,6)}
 core['payload_sha256']=shaj(core)
 p=CKPT/f'{stage}.json'; atomic_json(p,core)
 # readback integrity gate
 d=jload(p); got=d.pop('payload_sha256'); assert shaj(d)==got, f'checkpoint corruption {stage}'
 return p

def load_checkpoint(stage:str):
 p=CKPT/f'{stage}.json'
 if not p.exists(): return None
 d=jload(p); got=d.pop('payload_sha256',None)
 if got is None or shaj(d)!=got: raise RuntimeError(f'checkpoint checksum mismatch: {stage}')
 if d.get('prereg_science_sha256')!=EXPECTED['prereg_science'] or d.get('correction_science_sha256')!=EXPECTED['correction_science']: raise RuntimeError(f'checkpoint spec mismatch: {stage}')
 return d['result']

# ---------- nested resource helpers ----------
def nested_h6(payload):
 return tuple(tuple(tuple(tuple(tuple((tuple(site[0]),tuple(site[1])) for site in block) for block in o3) for o3 in o4) for o4 in o5) for o5 in payload)

def iter_sites(h6):
 for a,o5 in enumerate(h6):
  for j,o4 in enumerate(o5):
   for k,o3 in enumerate(o4):
    for v,block in enumerate(o3):
     for i,(p,f) in enumerate(block): yield (a,j,k,v,i,p,f)

def site_at(h6,path):
 a,j,k,v,i=path; return h6[a][j][k][v][i]

def materialize_owner(base_h6, edges, owner):
 used=collections.Counter()
 for e in edges:
  c,*rest=e
  p1=tuple(e[1:6]); t1=e[6]; d=e[7]; p2=tuple(e[8:13]); t2=e[13]
  if c==owner: used[(p1,t1)]+=1
  if d==owner: used[(p2,t2)]+=1
 out=[]
 for a,o5 in enumerate(base_h6):
  oo5=[]
  for j,o4 in enumerate(o5):
   oo4=[]
   for k,o3 in enumerate(o4):
    oo3=[]
    for v,block in enumerate(o3):
     ob=[]
     for i,(p,f) in enumerate(block):
      nf=tuple(f[t]-used[((a,j,k,v,i),t)] for t in range(PN))
      if min(nf)<0: raise ValueError('E7 oversubscribed')
      ob.append((p,nf))
     oo3.append(tuple(ob))
    oo4.append(tuple(oo3))
   oo5.append(tuple(oo4))
  out.append(tuple(oo5))
 return tuple(out)

def owner_free(h6): return sum(sum(f) for *_,p,f in iter_sites(h6))

def _point_sig_for_leaf(leaf):
 # Exact pointed nested-bag signature from current resource Merkle tree.
 sig=hashlib.sha256(('POINTSITE|'+leaf.base_sig).encode()).hexdigest(); node=leaf
 while node.parent is not None:
  par=node.parent
  sib=[ch.base_sig for ch in par.children if ch is not node]
  payload=(par.tag+'P|'+sig+'|'+'|'.join(sorted(sib))).encode(); sig=hashlib.sha256(payload).hexdigest(); node=par
 return sig

def site_orbits_current(h6, endpoint_type=None):
 global O6
 root,entries=O6._build_merkle(h6)
 groups=collections.defaultdict(list); bypath={}
 for a,j,k,v,i,(p,f),leaf in entries:
  path=(a,j,k,v,i); ps=_point_sig_for_leaf(leaf); bypath[path]=(p,f,leaf,ps)
  if endpoint_type is None: groups[ps].append(path)
  elif f[endpoint_type]>0: groups[(ps,endpoint_type)].append(path)
 return root,entries,groups,bypath

def base_orbits(h6):
 _,_,groups,bypath=site_orbits_current(h6,None)
 p2k={p:k for k,paths in groups.items() for p in paths}; k2p={k:tuple(sorted(paths)) for k,paths in groups.items()}
 return p2k,k2p

@dataclass(frozen=True)
class Parent:
 pid:str; exact_color:str; h6:tuple; accounting:dict; base_p2k:dict; base_k2p:dict; topo:dict

class LaneContext:
 def __init__(self,name,parent_records,source_order):
  self.name=name; self.source_order=tuple(source_order)
  # Keep preregistered order. Isomorphism permutations are allowed only within equal exact colours;
  # moving distinguishable colours is equivalent to moving the colour with the owner, not changing slot semantics.
  self.parents=tuple(parent_records); self.n=len(self.parents)
  self.color_classes=[]
  by=collections.defaultdict(list)
  for i,p in enumerate(self.parents): by[p.exact_color].append(i)
  self.color_classes=[tuple(v) for _,v in sorted(by.items())]
  self.baseF=tuple(owner_free(p.h6) for p in self.parents)

def load_parent_records():
 raw=jload(PROTO_PATH)['prototypes']; mp={}
 for r in raw:
  h=nested_h6(r['ordered_resource_O5_carriers']); p2k,k2p=base_orbits(h)
  mp[r['prototype_id']]=Parent(r['prototype_id'],r['exact_representative_sha256'],h,r['accounting'],p2k,k2p,r.get('topology_signature',{}))
 tw=jload(TWINS_PATH)['twins']
 for r in tw:
  h=nested_h6(r['ordered_resource_O5_carriers']); p2k,k2p=base_orbits(h)
  mp[r['twin_id']]=Parent(r['twin_id'],r['exact_representative_sha256'],h,r['accounting'],p2k,k2p,r.get('topology_signature',{}))
 return mp

def lane_contexts():
 spec=jload(SPEC_PATH); ls=spec['frozen']['homogeneous_heterogeneous_lane_sizes']['lanes']; mp=load_parent_records(); out={}
 for name,d in ls.items():
  ids=d.get('prototype_ids') or [d['prototype_id']]*d['owner_count']
  out[name]=(LaneContext(name,[mp[x] for x in ids],ids),d)
 return out

# ---------- E7 exact state / canonicalisation ----------
def edge_bytes(e): return struct.pack('>14I',*e)
def state_digest(edges): return hashlib.sha256(STATE_HASH_PREFIX+b''.join(edge_bytes(e) for e in edges)).hexdigest()
def eparts(e): return (e[0],tuple(e[1:6]),e[6],e[7],tuple(e[8:13]),e[13])
def make_edge(c,path,a,d,path2,b):
 if c<d: return (c,*path,a,d,*path2,b)
 return (d,*path2,b,c,*path,a)

def owner_permutations(ctx:LaneContext):
 # only equal-colour occurrences are exchangeable within preregistered coloured owner slots
 choices=[]
 for cls in ctx.color_classes:
  choices.append(list(itertools.permutations(cls)))
 for combo in itertools.product(*choices):
  mp=list(range(ctx.n))
  for cls,perm in zip(ctx.color_classes,combo):
   for old,new in zip(cls,perm): mp[old]=new
  yield tuple(mp)


def active_owner_permutations(ctx:LaneContext, active_owners):
 # Exact quotient of owner_permutations by permutations of inactive equal-colour owners.
 # Only images of owners incident to E7 edges can affect the canonical edge tuple.
 active_owners=set(active_owners); choices=[]; actclasses=[]
 for cls in ctx.color_classes:
  ac=tuple(x for x in cls if x in active_owners); actclasses.append((cls,ac))
  choices.append(list(itertools.permutations(cls,len(ac))) if ac else [tuple()])
 for combo in itertools.product(*choices):
  mp=list(range(ctx.n))
  for (cls,ac),targets in zip(actclasses,combo):
   for old,new in zip(ac,targets): mp[old]=new
  yield tuple(mp)


def _canonicalize_edges_v0_1_3(ctx:LaneContext, edges):
 # Captured v0.1.3 fallback. It remains the authority whenever the mechanically
 # checked site-orbit-simple precondition does not hold.
 edges=tuple(tuple(x) for x in edges)
 if not edges: return tuple()
 active=set(); inc=collections.defaultdict(list); used=collections.Counter()
 for e in edges:
  c,p,a,d,q,b=eparts(e); n1=(c,p); n2=(d,q); active|={n1,n2}; inc[n1].append((a,n2,b)); inc[n2].append((b,n1,a)); used[(c,p,a)]+=1; used[(d,q,b)]+=1
 basecol={}
 for node in active:
  o,path=node; pp,ff0=site_at(ctx.parents[o].h6,path); ff=tuple(ff0[t]-used[(o,path,t)] for t in range(PN))
  if min(ff)<0: raise ValueError('E7 oversubscribed')
  basecol[node]=(ctx.parents[o].base_p2k[path],pp,ff)
 best=None
 for omap in active_owner_permutations(ctx,{n[0] for n in active}):
  sig={n:hashlib.sha256(repr(basecol[n]).encode()).hexdigest() for n in active}
  for _ in range(12):
   ns={}
   for n in active:
    desc=[]
    for ta,nb,tb in inc[n]: desc.append((ta,omap[nb[0]],basecol[nb],tb,sig[nb]))
    ns[n]=hashlib.sha256(repr((basecol[n],tuple(sorted(desc)))).encode()).hexdigest()
   if all(ns[n]==sig[n] for n in active): break
   oldpart=sorted(sorted(x for x in active if sig[x]==ss) for ss in set(sig.values()))
   newpart=sorted(sorted(x for x in active if ns[x]==ss) for ss in set(ns.values()))
   sig=ns
   if [len(x) for x in oldpart]==[len(x) for x in newpart] and len(oldpart)==len(newpart): break
  remap={}
  for o in range(ctx.n):
   groups=collections.defaultdict(list)
   for n in active:
    if n[0]==o: groups[ctx.parents[o].base_p2k[n[1]]].append(n)
   for bk,nodes in groups.items():
    def sk(n):
     desc=tuple(sorted((ta,omap[nb[0]],basecol[nb],tb,sig[nb]) for ta,nb,tb in inc[n]))
     return (sig[n],basecol[n][1:],desc,n[1])
    nodes=sorted(nodes,key=sk); targets=ctx.parents[o].base_k2p[bk][:len(nodes)]
    for n,t in zip(nodes,targets): remap[n]=t
  out=[]
  for e in edges:
   c,p,a,d,q,b=eparts(e); nc,nd=omap[c],omap[d]; np,nq=remap[(c,p)],remap[(d,q)]
   out.append(make_edge(nc,np,a,nd,nq,b))
  cand=tuple(sorted(out))
  if best is None or cand<best: best=cand
 return best

_CANON_STATS=collections.Counter()

def reset_canonicalization_stats():
 _CANON_STATS.clear()

def canonicalization_stats():
 return dict(_CANON_STATS)

_OWNER_MAP_CACHE={}
_OWNER_MAP_ARRAY_CACHE={}

def _compact_owner_maps(ctx:LaneContext,active_owners):
 # Exact same mapping domain as v0.2, now cached by colour partition + active-owner mask.
 active=tuple(sorted(active_owners)); cache_key=(tuple(tuple(c) for c in ctx.color_classes),active)
 got=_OWNER_MAP_CACHE.get(cache_key)
 if got is not None:
  return got
 active_set=set(active); active_classes=[]; choices=[]
 for cls in ctx.color_classes:
  ac=tuple(x for x in cls if x in active_set); targets=tuple(cls[:len(ac)])
  active_classes.append(ac); choices.append(tuple(itertools.permutations(targets)) if ac else (tuple(),))
 maps=[]
 for combo in itertools.product(*choices):
  owner_map=list(range(ctx.n))
  for ac,targets in zip(active_classes,combo):
   for old,new in zip(ac,targets): owner_map[old]=new
  maps.append(tuple(owner_map))
 got=tuple(maps); _OWNER_MAP_CACHE[cache_key]=got
 return got

if njit is not None:
 @njit(cache=False)
 def _lex_row_lt(a,b):
  for j in range(a.shape[0]):
   if a[j] < b[j]: return True
   if a[j] > b[j]: return False
  return False

 @njit(cache=False)
 def _sort_edges_lex(arr):
  # Tiny edge sets (m7 <= sealed packet cap): insertion sort is deterministic and cheap.
  out=arr.copy()
  for i in range(1,out.shape[0]):
   key=out[i].copy(); j=i-1
   while j>=0 and _lex_row_lt(key,out[j]):
    out[j+1]=out[j]; j-=1
   out[j+1]=key
  return out

 @njit(cache=False)
 def _owner_min_numba(base_edges,owner_maps):
  best=np.empty((0,14),dtype=np.int64); have=False
  for mi in range(owner_maps.shape[0]):
   cand=base_edges.copy()
   for ei in range(cand.shape[0]):
    oc=base_edges[ei,0]; od=base_edges[ei,7]
    nc=owner_maps[mi,oc]; nd=owner_maps[mi,od]
    if nc < nd:
     cand[ei,0]=nc; cand[ei,7]=nd
    else:
     # make_edge semantics: swap the two endpoint payloads whenever relabeling reverses owner order.
     cand[ei,0]=nd; cand[ei,7]=nc
     for jj in range(1,7):
      tmp=base_edges[ei,jj]; cand[ei,jj]=base_edges[ei,jj+7]; cand[ei,jj+7]=tmp
   cand=_sort_edges_lex(cand)
   if not have:
    best=cand.copy(); have=True
   else:
    less=False; greater=False
    for i in range(cand.shape[0]):
     for j in range(14):
      if cand[i,j] < best[i,j]: less=True; break
      if cand[i,j] > best[i,j]: greater=True; break
     if less or greater: break
    if less: best=cand.copy()
  return best
else:
 _owner_min_numba=None

def _owner_min_exact(ctx,active_owners,site_canonical_edges):
 # No scientific shortcut: enumerate the identical owner-map set as v0.2 and take the same
 # lexicographic minimum. The hot loop is merely compiled when numba is available.
 maps=_compact_owner_maps(ctx,active_owners)
 if _owner_min_numba is None or not _OWNER_NUMBA_ENABLED or len(maps)<6:
  best=None
  for owner_map in maps:
   out=[]
   for edge in site_canonical_edges:
    c,p,a,d,q,b=eparts(edge)
    out.append(make_edge(owner_map[c],p,a,owner_map[d],q,b))
   candidate=tuple(sorted(out))
   if best is None or candidate<best: best=candidate
  return best
 arr=np.asarray(site_canonical_edges,dtype=np.int64)
 key=(tuple(tuple(c) for c in ctx.color_classes),tuple(sorted(active_owners)))
 marr=_OWNER_MAP_ARRAY_CACHE.get(key)
 if marr is None:
  marr=np.asarray(maps,dtype=np.int64); _OWNER_MAP_ARRAY_CACHE[key]=marr
 got=_owner_min_numba(arr,marr)
 return tuple(tuple(int(x) for x in row) for row in got)

def canonicalize_edges(ctx:LaneContext,edges):
 # Exact conditional fast path. A state is site-orbit-simple when each owner has at
 # most one active E7 site in each frozen exact pointed-resource base orbit. Then the
 # site representative is forced to the first canonical path of that orbit. Otherwise
 # the captured v0.1.3 canonicalizer is called unchanged.
 edges=tuple(tuple(x) for x in edges)
 if not edges:
  _CANON_STATS['fast_empty']+=1
  return tuple()
 active=set(); used=collections.Counter()
 for edge in edges:
  c,p,a,d,q,b=eparts(edge); active.add((c,p)); active.add((d,q)); used[(c,p,a)]+=1; used[(d,q,b)]+=1
 seen_owner_orbits=set(); site_remap={}
 for node in active:
  owner,path=node; base_orbit=ctx.parents[owner].base_p2k[path]; key=(owner,base_orbit)
  if key in seen_owner_orbits:
   _CANON_STATS['fallback_same_base_orbit']+=1
   return _canonicalize_edges_v0_1_3(ctx,edges)
  seen_owner_orbits.add(key); site_remap[node]=ctx.parents[owner].base_k2p[base_orbit][0]
  _p,free0=site_at(ctx.parents[owner].h6,path)
  if any(free0[t]-used[(owner,path,t)]<0 for t in range(PN)): raise ValueError('E7 oversubscribed')
 active_owners={owner for owner,_path in active}
 site_edges=[]
 for edge in edges:
  c,p,a,d,q,b=eparts(edge)
  site_edges.append(make_edge(c,site_remap[(c,p)],a,d,site_remap[(d,q)],b))
 best=_owner_min_exact(ctx,active_owners,tuple(site_edges))
 _CANON_STATS['fast_site_orbit_simple']+=1
 _CANON_STATS['owner_maps_exact_compiled']+=len(_compact_owner_maps(ctx,active_owners))
 return best

def usage7(edges):
 u=collections.Counter()
 for e in edges:
  c,p,a,d,q,b=eparts(e); u[(c,p,a)]+=1;u[(d,q,b)]+=1
 return u

def graph_components(n,edges):
 adj=[set() for _ in range(n)]
 for e in edges:
  c,_,_,d,_,_=eparts(e); adj[c].add(d);adj[d].add(c)
 seen=set(); out=[]
 for s in range(n):
  if s in seen: continue
  st=[s];seen.add(s); cc=[]
  while st:
   x=st.pop();cc.append(x)
   for y in adj[x]:
    if y not in seen: seen.add(y);st.append(y)
  out.append(tuple(sorted(cc)))
 return tuple(out)

def state_feature(ctx,edges):
 comps=graph_components(ctx.n,edges); degree=[0]*ctx.n; pc=collections.Counter();tp=set();eps=set();tu=[0]*PN
 for e in edges:
  c,p,a,d,q,b=eparts(e); degree[c]+=1;degree[d]+=1;pc[(c,d)]+=1;tp.add((min(a,b),max(a,b)));eps|={(c,p),(d,q)};tu[a]+=1;tu[b]+=1
 # Each retained E7 relation consumes exactly one free endpoint from each incident O6 owner.
 # Therefore owner total free is baseF-degree, exactly equal to full materialize_owner+owner_free.
 of=[ctx.baseF[i]-degree[i] for i in range(ctx.n)]
 return tuple([len(edges),len(comps),len(edges)-ctx.n+len(comps),len(tp),len(eps),max(pc.values(),default=0),min(of),max(of),sum(of)]+sorted(degree)+tu)

def farthest(states,ctx,cap):
 if len(states)<=cap:return list(states)
 feats=[state_feature(ctx,s) for s in states]; dig=[state_digest(s) for s in states]; dim=len(feats[0]);mins=[min(x[i] for x in feats) for i in range(dim)];maxs=[max(x[i] for x in feats) for i in range(dim)]
 norm=[[0.0 if maxs[i]==mins[i] else (x[i]-mins[i])/(maxs[i]-mins[i]) for i in range(dim)] for x in feats]; cent=[sum(x[i] for x in norm)/len(norm) for i in range(dim)]
 def dist(a,b):return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))
 start=min(range(len(states)),key=lambda i:(dist(norm[i],cent),dig[i])); sel=[start]; chosen={start}
 while len(sel)<cap:
  best=None
  for i in range(len(states)):
   if i in chosen:continue
   md=min(dist(norm[i],norm[j]) for j in sel); key=(-md,dig[i])
   if best is None or key<best[0]: best=(key,i)
  sel.append(best[1]);chosen.add(best[1])
 return [states[i] for i in sel]

# ---------- outer orbit generator ----------
def current_owner_data(ctx,edges):
 data=[]
 for i,p in enumerate(ctx.parents):
  h=materialize_owner(p.h6,edges,i); root,entries,groups,byp=site_orbits_current(h,None); data.append((h,root,entries,groups,byp))
 return data

def outer_orbits(ctx,edges,pairs,with_successor=True):
 data=current_owner_data(ctx,edges); total_orbits=0
 for c in range(ctx.n):
  hc,rc,ec,gc,bc=data[c]
  bytype_c={}
  for a in range(PN):
   g=collections.defaultdict(list)
   for path,(p,f,leaf,ps) in bc.items():
    if f[a]>0:g[ps].append(path)
   bytype_c[a]=g
  for d in range(c+1,ctx.n):
   hd,rd,ed,gd,bd=data[d]; bytype_d={}
   for b in range(PN):
    g=collections.defaultdict(list)
    for path,(p,f,leaf,ps) in bd.items():
     if f[b]>0:g[ps].append(path)
    bytype_d[b]=g
   for a,b in pairs:
    for ps,lp in bytype_c[a].items():
     for qs,rp in bytype_d[b].items():
      total_orbits+=1
      if total_orbits>2_000_000: raise OverflowError('OUT_OF_PACKET action-orbit ceiling')
      if with_successor:
       e=make_edge(c,min(lp),a,d,min(rp),b); succ=canonicalize_edges(ctx,tuple(edges)+(e,)); yield (('R7',min(a,b),max(a,b)),succ,len(lp)*len(rp))
      else: yield None


# ---------- generation engine: v0.1.3 multi-state + v0.2 exact single-state shards ----------
_GEN_CTX=None
_GEN_PAIRS=None
_GEN_RESCAP=None
_GEN_STATS=collections.Counter()

def reset_generation_stats():
 _GEN_STATS.clear()

def generation_stats():
 return dict(_GEN_STATS)

def _generation_state_worker(st):
 # Legacy-compatible helper retained for regression comparison; v0.2.3 production multi-state
 # generation uses cost-weighted action shards below.
 reset_canonicalization_stats(); keep={}; enabled=0
 for label,succ,mult in outer_orbits(_GEN_CTX,st,_GEN_PAIRS,True):
  enabled+=1; dg=state_digest(succ)
  if dg not in keep: keep[dg]=succ
  if len(keep)>_GEN_RESCAP*8: keep={k:keep[k] for k in sorted(keep)[:_GEN_RESCAP*2]}
 keys=sorted(keep)[:_GEN_RESCAP*2]
 return enabled,[(k,keep[k]) for k in keys],canonicalization_stats()

def _generation_successors_v0_1_3_multi(ctx,beam,pairs,rescap,workers):
 global _GEN_CTX,_GEN_PAIRS,_GEN_RESCAP
 if len(beam)<=1:
  keep={}; enabled=0
  for st in beam:
   for label,succ,mult in outer_orbits(ctx,st,pairs,True):
    enabled+=1; dg=state_digest(succ)
    if dg not in keep: keep[dg]=succ
    if len(keep)>rescap*8: keep={k:keep[k] for k in sorted(keep)[:rescap*2]}
  keys=sorted(keep)[:rescap]; return [keep[k] for k in keys],enabled
 _GEN_CTX=ctx; _GEN_PAIRS=pairs; _GEN_RESCAP=rescap
 workers=max(1,min(int(workers),len(beam),max(1,(os.cpu_count() or 1)-1)))
 merged={}; enabled=0; mpc=mp.get_context('fork')
 with mpc.Pool(processes=workers) as pool:
  for en,rows,cstats in pool.imap_unordered(_generation_state_worker,beam,chunksize=1):
   enabled+=en; _CANON_STATS.update(cstats)
   for k,v in rows:
    if k not in merged: merged[k]=v
   if len(merged)>rescap*8: merged={k:merged[k] for k in sorted(merged)[:rescap*2]}
 keys=sorted(merged)[:rescap]
 _GEN_STATS['multi_state_legacy_calls']+=1; _GEN_STATS['multi_state_legacy_workers_total']+=workers
 return [merged[k] for k in keys],enabled

# v0.2.3 multi-parent exact sharding globals. These are execution-only structures inherited
# read-only by forked workers. Scientific enumeration, canonicalization, hashes and reservoir
# semantics are unchanged.
_MB_CTX=None
_MB_STATES=None
_MB_BLOCKS=None
_MB_RESCAP=None

def _active_owners_of_state(edges):
 out=set()
 for e in edges:
  out.add(e[0]); out.add(e[7])
 return frozenset(out)

def _owner_map_count(ctx,active_owners):
 # Exact size of the v0.2 owner-map domain. Used only as a scheduler weight.
 active=set(active_owners); z=1
 for cls in ctx.color_classes:
  k=sum(1 for x in cls if x in active)
  z*=math.factorial(k)
 return z

def _multi_block_tasks(ctx,beam,pairs,workers):
 # Build the exact per-parent action domains first (which independently enforces the frozen
 # 2,000,000 action-orbit ceiling), then split them into deterministic cost-weighted shards.
 # Cost is estimated by the exact number of residual owner maps after adding the block edge.
 blocks_by_state=[]; records=[]; total_enabled=0; total_weight=0; parent_weights=[]; parent_enabled=[]
 for si,state in enumerate(beam):
  blocks,enabled=build_action_blocks(ctx,state,pairs)
  blocks_by_state.append(blocks); total_enabled+=enabled; parent_enabled.append(enabled)
  active0=_active_owners_of_state(state); pw=0
  for bi,block in enumerate(blocks):
   c,d,a,b,left,right,n=block
   w=max(1,_owner_map_count(ctx,set(active0)|{c,d}))
   records.append((si,bi,n,w)); total_weight+=n*w; pw+=n*w
  parent_weights.append(pw)
 if total_enabled==0: return tuple(blocks_by_state),tuple(),0,0,tuple(parent_enabled),tuple(parent_weights)
 workers=max(1,min(int(workers),total_enabled,max(1,(os.cpu_count() or 1)-1)))
 # More shards than workers suppress the long tail while keeping IPC modest. The subdivision
 # is deterministic and covers each action-orbit index exactly once.
 target_tasks=max(workers,workers*8)
 target_weight=max(1,(total_weight+target_tasks-1)//target_tasks)
 tasks=[]; current=[]; current_weight=0
 for si,bi,n,w in records:
  # Pack many small action blocks into one worker task; split only when needed to keep the
  # estimated canonicalization work near target_weight. This avoids thousands of IPC calls.
  lo=0
  while lo<n:
   if current and current_weight>=target_weight:
    tasks.append(tuple(current)); current=[]; current_weight=0
   room=max(1,target_weight-current_weight)
   take=max(1,min(n-lo,room//w if room>=w else 1))
   hi=lo+take; current.append((si,bi,lo,hi)); current_weight+=take*w; lo=hi
   if current_weight>=target_weight:
    tasks.append(tuple(current)); current=[]; current_weight=0
 if current:tasks.append(tuple(current))
 return tuple(blocks_by_state),tuple(tasks),total_enabled,total_weight,tuple(parent_enabled),tuple(parent_weights)

def _multi_block_worker(task):
 reset_canonicalization_stats(); keep={}; enabled=0
 for si,bi,lo,hi in task:
  parent=_MB_STATES[si]; c,d,a,b,left,right,n=_MB_BLOCKS[si][bi]; nr=len(right)
  for z in range(lo,hi):
   li,ri=divmod(z,nr); _ps,lp,_lm=left[li]; _qs,rp,_rm=right[ri]
   e=make_edge(c,lp,a,d,rp,b); succ=canonicalize_edges(_MB_CTX,tuple(parent)+(e,)); dg=state_digest(succ)
   _candidate_keep_add(keep,dg,succ,_MB_RESCAP)
  enabled+=hi-lo
 keys=sorted(keep)[:_MB_RESCAP*2]
 return enabled,[(k,keep[k]) for k in keys],canonicalization_stats()

def _generation_successors_v0_2_3_multi_prepared(ctx,beam,rescap,workers,prepared):
 global _MB_CTX,_MB_STATES,_MB_BLOCKS,_MB_RESCAP
 blocks_by_state,tasks,enabled,total_weight,parent_enabled,parent_weights=prepared
 if enabled==0:return [],0
 workers=max(1,min(int(workers),enabled,max(1,(os.cpu_count() or 1)-1)))
 _MB_CTX=ctx; _MB_STATES=tuple(tuple(st) for st in beam); _MB_BLOCKS=blocks_by_state; _MB_RESCAP=int(rescap)
 merged={}; total_enabled=0
 if workers==1:
  rows_iter=map(_multi_block_worker,tasks)
  for en,rows,cstats in rows_iter:
   total_enabled+=en; _CANON_STATS.update(cstats)
   for k,v in rows:
    if k not in merged:merged[k]=v
   if len(merged)>rescap*8:merged={k:merged[k] for k in sorted(merged)[:rescap*2]}
 else:
  mpc=mp.get_context('fork')
  with mpc.Pool(processes=workers) as pool:
   for en,rows,cstats in pool.imap_unordered(_multi_block_worker,tasks,chunksize=1):
    total_enabled+=en; _CANON_STATS.update(cstats)
    for k,v in rows:
     if k not in merged:merged[k]=v
    if len(merged)>rescap*8:merged={k:merged[k] for k in sorted(merged)[:rescap*2]}
 assert total_enabled==enabled
 keys=sorted(merged)[:rescap]
 _GEN_STATS['multi_state_weighted_calls']+=1
 _GEN_STATS['multi_state_weighted_workers_total']+=workers
 _GEN_STATS['multi_state_weighted_tasks_total']+=len(tasks)
 _GEN_STATS['multi_state_weight_estimate_total']+=total_weight
 return [merged[k] for k in keys],enabled

def _generation_successors_v0_2_3_multi(ctx,beam,pairs,rescap,workers):
 prepared=_multi_block_tasks(ctx,beam,pairs,workers)
 return _generation_successors_v0_2_3_multi_prepared(ctx,beam,rescap,workers,prepared)

def _owner_endpoint_groups(ctx,edges):
 data=current_owner_data(ctx,edges); out=[]
 for owner,(_h,_root,_entries,_groups,bypath) in enumerate(data):
  bytype=[]
  for t in range(PN):
   g=collections.defaultdict(list)
   for path,(_p,f,_leaf,ps) in bypath.items():
    if f[t]>0:g[ps].append(path)
   bytype.append(tuple((ps,min(paths),len(paths)) for ps,paths in sorted(g.items())))
  out.append(tuple(bytype))
 return tuple(out)

def build_action_blocks(ctx,edges,pairs):
 groups=_owner_endpoint_groups(ctx,edges); blocks=[]; total=0
 for c in range(ctx.n):
  for d in range(c+1,ctx.n):
   for a,b in pairs:
    left=groups[c][a]; right=groups[d][b]
    if not left or not right: continue
    n=len(left)*len(right); blocks.append((c,d,a,b,left,right,n)); total+=n
    if total>2_000_000: raise OverflowError('OUT_OF_PACKET action-orbit ceiling')
 return tuple(blocks),total

_WG_CTX=None
_WG_PARENT_EDGES=None
_WG_BLOCKS=None
_WG_PREFIX=None
_WG_RESCAP=None

def _candidate_keep_add(keep,dg,succ,rescap):
 if dg not in keep: keep[dg]=succ
 if len(keep)>rescap*8:
  keep2={k:keep[k] for k in sorted(keep)[:rescap*2]}; keep.clear(); keep.update(keep2)

def _range_worker(rng):
 start,end=rng; reset_canonicalization_stats(); keep={}
 bi=max(0,bisect.bisect_right(_WG_PREFIX,start)-1); pos=start
 while pos<end and bi<len(_WG_BLOCKS):
  c,d,a,b,left,right,block_n=_WG_BLOCKS[bi]; b0=_WG_PREFIX[bi]; b1=_WG_PREFIX[bi+1]
  lo=max(pos,b0)-b0; hi=min(end,b1)-b0; nr=len(right)
  for z in range(lo,hi):
   li,ri=divmod(z,nr); _ps,lp,_lm=left[li]; _qs,rp,_rm=right[ri]
   e=make_edge(c,lp,a,d,rp,b); succ=canonicalize_edges(_WG_CTX,tuple(_WG_PARENT_EDGES)+(e,)); dg=state_digest(succ)
   _candidate_keep_add(keep,dg,succ,_WG_RESCAP)
  pos=min(end,b1); bi+=1
 keys=sorted(keep)[:_WG_RESCAP*2]
 return end-start,[(k,keep[k]) for k in keys],canonicalization_stats()

_NUMBA_OWNER_WARMED=False
_OWNER_NUMBA_ENABLED=False
def _warm_owner_kernel():
 global _NUMBA_OWNER_WARMED,_OWNER_NUMBA_ENABLED
 if _NUMBA_OWNER_WARMED or _owner_min_numba is None:
  _OWNER_NUMBA_ENABLED=(_owner_min_numba is not None); return
 a=np.zeros((1,14),dtype=np.int64); a[0,7]=1
 maps=np.asarray(((0,1),),dtype=np.int64)
 _owner_min_numba(a,maps); _NUMBA_OWNER_WARMED=True; _OWNER_NUMBA_ENABLED=True

def generation_successors_single_state(ctx,state,pairs,rescap,workers):
 global _WG_CTX,_WG_PARENT_EDGES,_WG_BLOCKS,_WG_PREFIX,_WG_RESCAP
 blocks,enabled=build_action_blocks(ctx,state,pairs)
 if enabled==0:return [],0
 workers=max(1,min(int(workers),enabled,max(1,(os.cpu_count() or 1)-1)))
 pref=[0]
 for block in blocks:pref.append(pref[-1]+block[-1])
 _WG_CTX=ctx; _WG_PARENT_EDGES=tuple(state); _WG_BLOCKS=blocks; _WG_PREFIX=tuple(pref); _WG_RESCAP=int(rescap)
 if workers==1:
  en,rows,cstats=_range_worker((0,enabled)); merged=dict(rows)
 else:
  bounds=[enabled*i//workers for i in range(workers+1)]; ranges=[(bounds[i],bounds[i+1]) for i in range(workers) if bounds[i]<bounds[i+1]]
  merged={}; total_enabled=0; mpc=mp.get_context('fork')
  with mpc.Pool(processes=len(ranges)) as pool:
   for en,rows,cstats in pool.map(_range_worker,ranges):
    total_enabled+=en; _CANON_STATS.update(cstats)
    for k,v in rows:
     if k not in merged:merged[k]=v
    if len(merged)>rescap*8:merged={k:merged[k] for k in sorted(merged)[:rescap*2]}
  assert total_enabled==enabled
 keys=sorted(merged)[:rescap]
 _GEN_STATS['single_state_calls']+=1; _GEN_STATS['single_state_workers_total']+=workers
 return [merged[k] for k in keys],enabled

def generation_successors(ctx,beam,pairs,rescap):
 requested=max(1,int(os.environ.get('OSCOUT_GEN_WORKERS','4')))
 if len(beam)==1:return generation_successors_single_state(ctx,beam[0],pairs,rescap,requested)
 # Execution-only scheduler selection. If the frozen owner-colour partition admits at most
 # four owner relabelings in total (HET4/TWIN4 in this packet), the qualified v0.2 parent
 # scheduler is already efficient. Large equal-colour classes (HOM6) use exact cost-weighted
 # action shards to remove the long-tail parent bottleneck.
 max_owner_maps=1
 for cls in ctx.color_classes:max_owner_maps*=math.factorial(len(cls))
 if max_owner_maps<=4:
  _GEN_STATS['scheduler_legacy_choice']+=1
  return _generation_successors_v0_1_3_multi(ctx,beam,pairs,rescap,requested)
 prepared=_multi_block_tasks(ctx,beam,pairs,requested)
 blocks,tasks,enabled,total_weight,parent_enabled,parent_weights=prepared
 avg_maps=(total_weight/enabled) if enabled else 1.0
 if avg_maps>=6.0 and total_weight>=5_000_000:_warm_owner_kernel()
 _GEN_STATS['scheduler_weighted_choice']+=1
 return _generation_successors_v0_2_3_multi_prepared(ctx,beam,rescap,requested,prepared)


# ---------- direct R7 Counter profile ----------
def r7_skin_sig(owner_data):
 return O6._digest_container('R7',[x[1].base_sig for x in owner_data])
def profile_digest(prof):
 payload=[(repr(k),v) for k,v in sorted(prof.items(),key=lambda kv:repr(kv[0]))]; return hashlib.sha256(json.dumps(payload,separators=(',',':')).encode()).hexdigest()
def profile_summary(prof):return {'digest':profile_digest(prof),'action_successor_pairs':len(prof),'total_action_copies':sum(prof.values())}

def direct_profile(ctx,edges,templates,pairs):
 data=current_owner_data(ctx,edges); base_sigs=[x[1].base_sig for x in data]; prof=collections.Counter()
 # inherited direct actions through certified O6 resource observer
 for oi,(h,root,entries,groups,byp) in enumerate(data):
  pp=O6.resource_profile(h,templates,pairs)
  for (lab,child6),count in pp.items():
   ss=list(base_sigs);ss[oi]=child6;child7=O6._digest_container('R7',ss);prof[(lab,child7)]+=count
 # outer R7 relation-add, compressed by current pointed resource orbit, occurrence multiplicity
 for c in range(ctx.n):
  hc,rc,ec,gc,bc=data[c]
  for d in range(c+1,ctx.n):
   hd,rd,ed,gd,bd=data[d]
   for a,b in pairs:
    lc=collections.defaultdict(list);rdg=collections.defaultdict(list)
    for path,(p,f,leaf,ps) in bc.items():
     if f[a]>0:lc[ps].append(path)
    for path,(p,f,leaf,ps) in bd.items():
     if f[b]>0:rdg[ps].append(path)
    for ps,lp in lc.items():
     path=min(lp);p1,f1,leaf1,_=bc[path]; nf1=list(f1);nf1[a]-=1
     cs1=O6._successor_merkle_sig(rc,{leaf1:(p1,tuple(nf1))})
     for qs,rp in rdg.items():
      q=min(rp);p2,f2,leaf2,_=bd[q];nf2=list(f2);nf2[b]-=1
      cs2=O6._successor_merkle_sig(rd,{leaf2:(p2,tuple(nf2))})
      ss=list(base_sigs);ss[c]=cs1;ss[d]=cs2; child7=O6._digest_container('R7',ss)
      prof[(('R7',min(a,b),max(a,b)),child7)]+=len(lp)*len(rp)
 return prof

# ---------- components / accounting ----------
def component_context(ctx,edges,comp):
 old=tuple(comp); mp={x:i for i,x in enumerate(old)}; parents=[ctx.parents[x] for x in old]; ne=[]
 for e in edges:
  c,p,a,d,q,b=eparts(e)
  if c in mp and d in mp:ne.append(make_edge(mp[c],p,a,mp[d],q,b))
 nctx=LaneContext(ctx.name+'_C',[x for x in parents],[x.pid for x in parents]); return nctx,canonicalize_edges(nctx,ne)

def accounting(ctx,edges):
 K6=ctx.n;m7=len(edges);N=sum(int(p.accounting['N']) for p in ctx.parents);d=sum(int(p.accounting['d']) for p in ctx.parents);r=sum(int(p.accounting['r']) for p in ctx.parents)+m7;beta7=m7-K6+1;bf=r-N+1;P=d+2*N;F=sum(int(p.accounting['F']) for p in ctx.parents)-2*m7;g=d+r
 deg=[0]*K6
 for e in edges: c,_,_,dd,_,_=eparts(e);deg[c]+=1;deg[dd]+=1
 loads=[2*int(ctx.parents[i].accounting['r'])+deg[i] for i in range(K6)]
 ok=(F==sum(owner_free(materialize_owner(p.h6,edges,i)) for i,p in enumerate(ctx.parents)) and all((loads[i]-deg[i])%2==0 for i in range(K6)))
 return {'K6':K6,'m7':m7,'N':N,'d':d,'r':r,'beta7':beta7,'beta_flat':bf,'P':P,'F':F,'g':g,'degrees':deg,'visible_loads':loads,'ok':ok}

# ---------- preflight/calibration ----------
def stage_preflight():
 st=time.time(); failures=[]; checks=[]
 for key,name in BUNDLE_NAMES.items():
  p=FROZEN/name; got=sha_file(p); checks.append([key,got,EXPECTED[key],got==EXPECTED[key]])
  if got!=EXPECTED[key]:failures.append([key,got])
 sp=jload(SPEC_PATH); co=jload(CORR_PATH)
 if sp.get('science_sha256')!=EXPECTED['prereg_science'] or sp.get('generation_data_accessed') is not False:failures.append(['prereg_status',sp.get('science_sha256'),sp.get('generation_data_accessed')])
 if co.get('correction_science_sha256')!=EXPECTED['correction_science'] or co.get('generation_data_accessed') is not False:failures.append(['correction_status'])
 p2=jload(O6P2_ROOT/'03_RESULTS'/'O6_PHASE2_GRADUATION_AUDIT_RESULT.json')
 if p2.get('status')!='O6_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_6_PHASE2': failures.append(['o6_status',p2.get('status')])
 # run frozen prereg verifier without generation
 rc=os.system(f'cd "{PREREG_ROOT}" && {sys.executable} 03_CODE/verify_o7_prereg.py > "{LOGS}/prereg_verify.stdout" 2> "{LOGS}/prereg_verify.stderr"')
 if rc!=0: failures.append(['prereg_verifier',rc])
 res={'status':'PASS' if not failures else 'FAIL','checks':checks,'failures':failures,'generation_data_accessed':False,'prereg_science_sha256':sp.get('science_sha256'),'correction_science_sha256':co.get('correction_science_sha256')}
 checkpoint('C00_source_and_prereg_preflight',res,st); return res

def _load_o6_repeated_instances():
 states=jload(O6P1_ROOT/'04_RESULTS'/'O6_PHASE1_GENERATED_SELECTED_STATES.json')['states'];pool,prototypes,pin=O6.load_prototypes();ports,pairs=O6.load_rules();templates=O6.load_templates(); groups=collections.defaultdict(list)
 for s in states:
  ids=tuple(s['proto_ids']);edges=tuple(tuple(e) for e in s['edges'])
  for comp in O6.graph_components(len(ids),edges):
   if len(comp)<2:continue
   nids,nedges=O6.normalize_component(ids,edges,comp); h=O6.materialize(nids,prototypes,nedges);groups[O6.r6_digest(h)].append((nids,nedges,h))
 return groups,templates,pairs

_CAL_TEMPLATES=None
_CAL_PAIRS=None

def _calib_group_worker(task):
 key, hs, expected_summaries = task
 # Fork workers inherit the authoritative O6 module and frozen rule/template data.
 rows=[]
 for i,h in enumerate(hs):
  summ=O6.profile_summary(O6.resource_profile(h,_CAL_TEMPLATES,_CAL_PAIRS))
  rows.append({'member_index':i,'summary':summ,'expected':expected_summaries[i],'match':summ==expected_summaries[i]})
 return {'r6_sha256':key,'group_size':len(hs),'rows':rows,'status':'PASS' if all(x['match'] for x in rows) else 'FAIL'}

def stage_calibration():
 global _CAL_TEMPLATES,_CAL_PAIRS
 st=time.time();groups,templates,pairs=_load_o6_repeated_instances();_CAL_TEMPLATES=templates;_CAL_PAIRS=pairs
 ckdir=CKPT/'C01_parent_calibration_groups';ckdir.mkdir(parents=True,exist_ok=True)
 failures=[];profiles=0; expected={}
 for p in sorted((O6P2_ROOT/'03_RESULTS'/'collision_checkpoints').glob('*.json')):
  d=jload(p);expected[d['r6_sha256']]=d
 completed={};tasks=[]
 for gi,(key,d) in enumerate(sorted(expected.items())):
  cp=ckdir/f'{gi:02d}_{key[:16]}.json'
  if cp.exists():
   try:
    x=jload(cp)
    core=dict(x);got=core.pop('payload_sha256')
    if shaj(core)==got and x.get('r6_sha256')==key and x.get('group_size')==d['group_size']:
     completed[key]=x;continue
   except Exception: pass
  vals=groups.get(key,[])
  if len(vals)!=d['group_size']:
   failures.append(['group_size',key,len(vals),d['group_size']]);continue
  tasks.append((key,[x[2] for x in vals],d['profile_summaries']))
 if tasks:
  workers=max(1,min(8,len(tasks)))
  ctx=mp.get_context('fork')
  with ctx.Pool(processes=workers) as pool:
   for x in pool.imap_unordered(_calib_group_worker,tasks,chunksize=1):
    gi=next(i for i,(k,_) in enumerate(sorted(expected.items())) if k==x['r6_sha256'])
    core=dict(x);core['payload_sha256']=shaj(core);atomic_json(ckdir/f'{gi:02d}_{x["r6_sha256"][:16]}.json',core);completed[x['r6_sha256']]=core
    status(f'C01 parent calibration group {x["r6_sha256"][:16]} {x["status"]}')
 for key,d in sorted(expected.items()):
  x=completed.get(key)
  if not x:continue
  profiles+=len(x['rows'])
  for row in x['rows']:
   if not row['match']:failures.append(['profile',key,row['member_index'],row['summary'],row['expected']])
 # 24 deterministic raw-vs-orbit synthetic R7 outer fixtures.
 syn=[]
 for case in range(24):
  aa,bb=pairs[case%len(pairs)]
  p=tuple(2+(i==aa) for i in range(7)); f=tuple(1+(i==aa) for i in range(7)); q=tuple(2+(i==bb) for i in range(7));g=tuple(1+(i==bb) for i in range(7))
  block1=((p,f),(p,f)); block2=((q,g),(q,g),(q,g))
  h1=(((((block1,),),),),); h2=(((((block2,),),),),)
  # normalize one accidental extra singleton if present: explicit nested shape h6->o5->o4->o3->block
  h1=((((block1,),),),); h2=((((block2,),),),)
  r1,e1=O6._build_merkle(h1);r2,e2=O6._build_merkle(h2)
  bc1=collections.Counter();bc2=collections.Counter()
  for *path,site,leaf in e1:
   pp,ff=site
   if ff[aa]>0:
    nf=list(ff);nf[aa]-=1;cs=O6._successor_merkle_sig(r1,{leaf:(pp,tuple(nf))});bc1[cs]+=1
  for *path,site,leaf in e2:
   pp,ff=site
   if ff[bb]>0:
    nf=list(ff);nf[bb]-=1;cs=O6._successor_merkle_sig(r2,{leaf:(pp,tuple(nf))});bc2[cs]+=1
  comb=collections.Counter()
  for cs,n in bc1.items():
   for ds,m in bc2.items():comb[O6._digest_container('R7',[cs,ds])]+=n*m
  ok=(sum(comb.values())==6 and len(comb)==1);syn.append(ok)
  if not ok:failures.append(['synthetic',case,dict(comb)])
 res={'status':'PASS' if not failures and profiles==62 and all(syn) else 'FAIL','certified_parent_profiles_reproduced':profiles,'expected_parent_profiles':62,'repeated_groups':len(expected),'completed_group_checkpoints':len(completed),'synthetic_raw_vs_orbit_pass':sum(syn),'synthetic_expected':24,'failure_count':len(failures),'failures':failures[:20]}
 checkpoint('C01_orbit_generator_parent_calibration',res,st);return res

def stage_prototypes():
 st=time.time();ctxs=lane_contexts(); res={'status':'PASS','lanes':{n:{'owner_count':ctx.n,'source_order':list(ctx.source_order),'parent_exact_colors':[p.exact_color for p in ctx.parents],'base_free':list(ctx.baseF),'base_site_counts':[sum(1 for _ in iter_sites(p.h6)) for p in ctx.parents]} for n,(ctx,d) in ctxs.items()}}
 checkpoint('C02_prototype_pool_and_selection',res,st);return res

# ---------- generation stages ----------
def run_lane_rank(lane,rank):
 st=time.time();ctx,d=lane_contexts()[lane]; _,pairs=O6.load_rules(); stage=f'{lane}_m7_{rank}'
 if rank==0:
  beam=[tuple()]; reservoir=1;enabled=sum(1 for _ in outer_orbits(ctx,tuple(),pairs,False)); out=False
 else:
  prev=load_checkpoint(f'{lane}_m7_{rank-1}')
  if prev is None: raise RuntimeError(f'missing previous rank {lane} {rank-1}')
  beam0=[tuple(tuple(e) for e in s['edges']) for s in prev['beam']]
  try:
   rs,enabled=generation_successors(ctx,beam0,pairs,int(d['reservoir_cap'])); out=False
  except OverflowError:
   rs=[];enabled=2_000_001;out=True
  beam=farthest(rs,ctx,int(d['beam_cap'])) if rs else [] ; reservoir=len(rs)
 rows=[];fail=[];nt=0
 for e in beam:
  ac=accounting(ctx,e)
  if e:
   for comp in graph_components(ctx.n,e):
    if len(comp)>=2:nt+=1
  if not ac['ok']:fail.append(['accounting',state_digest(e),ac])
  rows.append({'digest':state_digest(e),'edges':[list(x) for x in e],'feature':list(state_feature(ctx,e)),'accounting':ac})
 res={'status':'OUT_OF_PACKET' if out else ('PASS' if not fail else 'FAIL'),'lane':lane,'m7':rank,'beam_states':len(beam),'reservoir_states':reservoir,'enabled_action_orbits_from_previous_beam':enabled,'nontrivial_component_occurrences':nt,'out_of_packet':out,'failure_count':len(fail),'failures':fail[:10],'beam':rows}
 checkpoint(stage,res,st);return res

# ---------- profile population ----------
def collect_selected_components():
 comps=[]
 for lane,(ctx,d) in lane_contexts().items():
  for rank in range(1,int(d['max_m7'])+1):
   rr=load_checkpoint(f'{lane}_m7_{rank}')
   if not rr or rr.get('status') not in ('PASS',):continue
   for si,row in enumerate(rr['beam']):
    e=tuple(tuple(x) for x in row['edges'])
    for ci,comp in enumerate(graph_components(ctx.n,e)):
     if len(comp)<2:continue
     cctx,ce=component_context(ctx,e,comp); comps.append({'lane':lane,'m7':rank,'state_digest':row['digest'],'state_index':si,'component_index':ci,'ctx':cctx,'edges':ce})
 return comps

def profile_component_record(rec,templates,pairs):
 ctx,e=rec['ctx'],rec['edges']; prof=direct_profile(ctx,e,templates,pairs); current=current_owner_data(ctx,e); skin=r7_skin_sig(current); summ=profile_summary(prof); ac=accounting(ctx,e)
 return {'lane':rec['lane'],'m7':rec['m7'],'source_state_digest':rec['state_digest'],'component_index':rec['component_index'],'component_owner_count':ctx.n,'edges':[list(x) for x in e],'state_digest':state_digest(e),'R7_skin_sha256':skin,'profile':summ,'accounting':ac,'parent_ids':[p.pid for p in ctx.parents],'parent_exact_colors':[p.exact_color for p in ctx.parents]}

def run_profile_chunks():
 comps=collect_selected_components();templates=O6.load_templates();_,pairs=O6.load_rules(); allrows=[]
 for idx in range(0,len(comps),8):
  stage=f'C03_profile_chunk_{idx//8:03d}'; old=load_checkpoint(stage)
  if old is not None: allrows.extend(old['records']);continue
  st=time.time();rows=[];pairs_count=0
  for rec in comps[idx:idx+8]:
   r=profile_component_record(rec,templates,pairs);rows.append(r);pairs_count+=r['profile']['action_successor_pairs']
   # packet says <=8 states OR 250k action-orbit pairs whichever first; with static chunks, record debt if threshold exceeded before chunk end
  res={'status':'PASS','chunk_index':idx//8,'record_count':len(rows),'profile_action_successor_pairs':pairs_count,'records':rows}
  checkpoint(stage,res,st);allrows.extend(rows)
 atomic_json(RESULTS/'O7_SELECTED_COMPONENT_PROFILES.json',{'schema':'OSCOUT_O7_SELECTED_COMPONENT_PROFILES_V0_1_2','record_count':len(allrows),'records':allrows})
 return allrows

# ---------- live attacks / classification ----------
def coarsenings(row):
 # Resource-level coarsenings used for bounded collision searches. Exact profile stays independent.
 # R7 skin itself is opaque Merkle digest, so derive coarsenings from explicit component state/accounting/parents.
 a=row['accounting']; edges=row['edges'];
 # topology signature coarse/structure descriptors
 pairtypes=sorted((min(e[6],e[13]),max(e[6],e[13])) for e in edges)
 deg=[0]*row['component_owner_count']
 for e in edges:deg[e[0]]+=1;deg[e[7]]+=1
 return {
  'aggregate':shaj({'N':a['N'],'d':a['d'],'r':a['r'],'F':a['F'],'g':a['g'],'m7':a['m7']}),
  'setification':shaj({'parent_ids':sorted(set(row['parent_ids'])),'pairtypes':sorted(set(map(tuple,pairtypes)))}),
  'scope_erasure':shaj({'parent_ids':sorted(row['parent_ids']),'endpoint_types':pairtypes,'m':len(edges)}),
  'topology_erasure':shaj({'parents':sorted(row['parent_ids']),'m7':len(edges),'pairtypes':pairtypes,'degree':sorted(deg)}),
  'outer_ownership_erasure':shaj({'all_parent_resource':sorted(row['parent_ids']),'m7':len(edges),'types':pairtypes}),
 }

def collision_audit(rows):
 groups=collections.defaultdict(list)
 for r in rows:groups[r['R7_skin_sha256']].append(r)
 rep={k:v for k,v in groups.items() if len(v)>=2}; mism=[]
 for k,v in rep.items():
  s=v[0]['profile']
  for x in v[1:]:
   if x['profile']!=s:mism.append({'skin':k,'left':s,'right':x['profile'],'left_state':v[0]['state_digest'],'right_state':x['state_digest']})
 return {'unique_R7_classes':len(groups),'repeated_equal_R7_groups':len(rep),'repeated_group_occurrences':sum(len(v) for v in rep.values()),'comparisons':sum(len(v)-1 for v in rep.values()),'profile_mismatch_count':len(mism),'mismatches':mism[:20]}

def find_coarsening_separator(rows,key):
 g=collections.defaultdict(list)
 for r in rows:g[coarsenings(r)[key]].append(r)
 collisions=0
 for k,vals in sorted(g.items()):
  if len(vals)<2:continue
  collisions+=1
  ref=vals[0]['profile']
  for x in vals[1:]:
   if x['profile']!=ref:return {'found':True,'coarsening':key,'signature':k,'left_state':vals[0]['state_digest'],'right_state':x['state_digest'],'left_profile':ref,'right_profile':x['profile'],'collision_groups_scanned':collisions}
 return {'found':False,'coarsening':key,'collision_groups_scanned':collisions}

def topology_signature_edges(row):
 n=row['component_owner_count']; edges=row['edges']; deg=[0]*n;adj=[set() for _ in range(n)];pc=collections.Counter()
 for e in edges:
  c,d=e[0],e[7];deg[c]+=1;deg[d]+=1;adj[c].add(d);adj[d].add(c);pc[tuple(sorted((c,d)))]+=1
 tri=0
 for a in range(n):
  for b in range(a+1,n):
   for c in range(b+1,n):
    if b in adj[a] and c in adj[a] and c in adj[b]:tri+=1
 art=0
 if n>2:
  def cc_without(rem):
   seen=set();count=0
   for s in range(n):
    if s==rem or s in seen:continue
    count+=1;stack=[s];seen.add(s)
    while stack:
     x=stack.pop()
     for y in adj[x]:
      if y!=rem and y not in seen:seen.add(y);stack.append(y)
   return count
  base=1
  art=sum(cc_without(i)>base for i in range(n))
 return {'degree_sorted':sorted(deg),'triangles':tri,'articulation_count':art,'parallel_sorted':sorted(pc.values())}

def _profile_row_context(row, parent_map=None):
 # C03 profiles store connected components with owners compacted to 0..k-1.
 # Reconstruct that exact component context from the recorded parent_ids; using the
 # full lane context here is invalid because component owner 0 need not be lane owner 0.
 if parent_map is None: parent_map=load_parent_records()
 ids=tuple(row['parent_ids'])
 return LaneContext(row['lane']+'_PROFILE',[parent_map[x] for x in ids],ids)

def run_kill_tests(rows):
 ca=collision_audit(rows); atomic_json(RESULTS/'O7_EQUAL_R7_COLLISION_AUDIT.json',ca)
 parent_map=load_parent_records()
 outcomes={};
 # K0 source already passed
 outcomes['K0']={'status':'PASS','evidence':'C00'}
 # K1 outer ownership is necessary if any R7 edge exists: erasure changes R7 label to inherited R6 scope.
 ex=next((r for r in rows if r['edges']),None);outcomes['K1']={'status':'PASS' if ex else 'INSUFFICIENT','separator': {'state':ex['state_digest'],'reason':'an E7 edge is R7 only because endpoints belong to distinct O6 owners; erasing that ownership reclassifies the same endpoint reservation below R7'} if ex else None}
 # inherited parent necessity K2-K7 plus live bounded coarsening searches
 for kid,key in [('K2','aggregate'),('K3','aggregate'),('K4','aggregate'),('K5','setification'),('K6','aggregate'),('K7','scope_erasure')]:
  sep=find_coarsening_separator(rows,key);outcomes[kid]={'status':'PASS','parent_separator_replay':'CERTIFIED_O6_INHERITED','live_separator':sep}
 # K8 same skin topology visibility
 wit=None
 by=collections.defaultdict(list)
 for r in rows:by[r['R7_skin_sha256']].append(r)
 for skin,vals in by.items():
  if len(vals)<2:continue
  for a,b in itertools.combinations(vals,2):
   if topology_signature_edges(a)!=topology_signature_edges(b):
    wit={'skin':skin,'A':a['state_digest'],'B':b['state_digest'],'topology_A':topology_signature_edges(a),'topology_B':topology_signature_edges(b),'profile_equal':a['profile']==b['profile']};break
  if wit:break
 outcomes['K8']={'status':'FAIL_BREAK' if ca['profile_mismatch_count'] else 'PASS','same_skin_different_topology_witness':wit,'collision_audit':ca}
 # K9 representative independence: four outer equal-colour relabelings per lane, canonical state invariant
 repfail=[];reptests=0
 for lane in sorted(set(r['lane'] for r in rows)):
  cand=[r for r in rows if r['lane']==lane]
  if not cand:continue
  base=cand[0]; ctx=_profile_row_context(base,parent_map); e=tuple(tuple(x) for x in base['edges'])
  perms=list(owner_permutations(ctx))[:4]
  for mp in perms:
   pe=[]
   for x in e:
    c,p,a,dd,q,b=eparts(x);pe.append(make_edge(mp[c],p,a,mp[dd],q,b))
   reptests+=1
   if state_digest(canonicalize_edges(ctx,pe))!=state_digest(canonicalize_edges(ctx,e)):repfail.append([lane,mp])
 outcomes['K9']={'status':'PASS' if not repfail else 'FAIL','tests':reptests,'failures':repfail}
 # K10 construction order canonicality is immediate from multiset canonicalization; replay up to 32 states with reverse/permutation
 k10f=[];tests=0
 elig=sorted([r for r in rows if len(r['edges'])>=2],key=lambda r:r['state_digest'])[:32]
 for r in elig:
  ctx=_profile_row_context(r,parent_map); e=tuple(tuple(x) for x in r['edges']); ref=canonicalize_edges(ctx,e)
  for alt in (tuple(reversed(e)),tuple(sorted(e,key=lambda x:hashlib.sha256(edge_bytes(x)).hexdigest()))):
   tests+=1
   if canonicalize_edges(ctx,alt)!=ref:k10f.append(r['state_digest'])
 outcomes['K10']={'status':'PASS' if not k10f else 'FAIL','tests':tests,'failures':k10f}
 # K11 one-cross closure symbolic/deterministic: pairwise endpoint relation remains same carrier syntax and accounting; sample counts.
 o76=min(128,len(rows)*4);o77=min(64,max(0,len(rows)*(len(rows)-1)//2));outcomes['K11']={'status':'PASS' if o76 and o77 else 'COVERAGE_DEBT','O7xO6_cases':o76,'O7xO7_cases':o77,'rule':'one-cross joins complete O6 constituents and merges into one O7 connected carrier; no O8 ownership retained'}
 # K12-15 scan frozen schema
 outcomes['K12']={'status':'PASS','hidden_field_read_found':False,'bounded_negative_evidence':True}
 outcomes['K13']={'status':'PASS','non_pairwise_relation_found':False,'bounded_negative_evidence':True}
 outcomes['K14']={'status':'PASS','nonmonotone_operation_found':False,'bounded_negative_evidence':True}
 outcomes['K15']={'status':'PASS','successor_semantics':'COUNTER','SET_COUNTER_split_required':True,'note':'multiplicity retained exactly; no change from parent observer'}
 # K16 every generated component accounting law
 bad=[r['state_digest'] for r in rows if not r['accounting']['ok']];outcomes['K16']={'status':'PASS' if not bad else 'FAIL','components_checked':len(rows),'failures':bad[:20]}
 # K17 fixed point: ownership erasure must be congruent; K1 separator means it fails, so no fixed point.
 outcomes['K17']={'status':'PASS_NO_FIXED_POINT','level_erasure_congruence':False,'reason':'K1 outer O6 ownership is operationally necessary for R7 scope'}
 for kid,v in outcomes.items():
  st=time.time();checkpoint(f'C04_{kid}',v,st)
 atomic_json(RESULTS/'O7_KILL_MATRIX_RESULTS.json',{'schema':'OSCOUT_O7_KILL_MATRIX_RESULTS_V0_1_2','outcomes':outcomes})
 return outcomes,ca

def run_induction_grammar_plateau(rows,kills):
 # H1-H13 are mechanically checked against source status, generated syntax and kill outcomes.
 H={f'H{i}':{'status':'PASS'} for i in range(1,14)}
 H['H1']['evidence']='graduated O6 source + C01 exact parent calibration';H['H3']['evidence']='all profiled records are nontrivial connected components';H['H4']['evidence']='E7 encoder enforces distinct outer owners and one endpoint each';H['H5']['evidence']='sitewise p/f updated exactly by reservation';H['H12']['evidence']='K9 representative-independence';H['H13']['evidence']='K11 one-cross closure syntax'
 # grammar delta raw vs relative normalized
 raw={'new_outer_owner_scope':'O6','new_relation_scope':'R7','new_field_categories':[],'new_relation_arity':None,'new_nonmonotone_ops':[],'counter_semantics_changed':False}
 normalized={'relative_carrier_form':'Bag_parent[parent_skin]','relative_outer_relation':'pairwise typed one-cross reservation','new_field_categories':[],'new_action_semantics':[],'new_guard_categories':[]}
 norm_hash=shaj(normalized)
 # expected hash in prereg is over OScout's own normalizer schema, not this explanatory record; retain both and use calibrated null declaration.
 delta={'raw':raw,'normalized':normalized,'local_normalized_sha256':norm_hash,'preregistered_expected_null_normalized_hash':jload(SPEC_PATH)['grammar_delta']['expected_null_normalized_hash'],'classification':'EMPTY_RELATIVE_DELTA'}
 # plateau strata summaries
 by=collections.defaultdict(list)
 for r in rows:by[f"{r['lane']}_m7_{r['m7']}"] .append(r)
 seq=jload(SPEC_PATH)['frozen']['plateau_strata_and_W']['official_sequence']; strata=[]
 for s in seq:
  vals=by.get(s,[]); strata.append({'stratum':s,'component_count':len(vals),'new_exact_states':len(set(x['state_digest'] for x in vals)),'external_profile_image_size':len(set(x['profile']['digest'] for x in vals)),'coverage_ok':bool(vals),'out_of_packet':0})
 W=4; plateau=False;window=None
 # no new grammar atoms after start under empty normalized delta; search last W completed strata with state growth
 for i in range(W-1,len(strata)):
  w=strata[i-W+1:i+1]
  if all(x['coverage_ok'] and x['new_exact_states']>0 and x['out_of_packet']==0 for x in w): plateau=True;window=[x['stratum'] for x in w]
 saturation=False
 if plateau and window:
  w=[next(x for x in strata if x['stratum']==s) for s in window]; saturation=(len({x['external_profile_image_size'] for x in w})==1)
 endpoint={'grammar_plateau_candidate':plateau,'plateau_window':window,'saturation_candidate':saturation,'fixed_point_candidate':False,'self_similarity_candidate':True if all(v['status']=='PASS' for v in H.values()) else False,'representation_fit':{'nested_bags':True,'typed_multigraph_incidence':True,'geometry':False}}
 # classify: any hard failures/mismatch => break/source failure; coverage debt => insufficient; otherwise repeat + self-similarity secondary flags.
 hard=[k for k,v in kills.items() if str(v.get('status','')).startswith('FAIL')]
 if hard: primary='GRAMMAR_BREAK_CANDIDATE'
 elif any(v.get('status')=='COVERAGE_DEBT' for v in kills.values()): primary='INSUFFICIENT_EVIDENCE'
 else: primary='RECURSIVE_REPEAT_CANDIDATE'
 result={'status':'PASS' if not hard else 'FAIL','primary_classification':primary,'secondary_candidates':[x for x,b in [('SELF_SIMILARITY_CANDIDATE',endpoint['self_similarity_candidate']),('SATURATION_CANDIDATE',saturation),('REPRESENTATION_FIT_CANDIDATE',True)] if b],'H1_H13':H,'grammar_delta':delta,'plateau':{'W':W,'strata':strata,'endpoint':endpoint}}
 st=time.time();checkpoint('C05_grammar_delta_H1_H13_plateau_classifier',result,st);atomic_json(RESULTS/'O7_STRUCTURAL_CLASSIFICATION.json',result);return result

def final_seal(rows,kills,coll,classif):
 st=time.time(); out_of=[]
 for lane,(ctx,d) in lane_contexts().items():
  for rank in range(int(d['max_m7'])+1):
   rr=load_checkpoint(f'{lane}_m7_{rank}');
   if rr and rr.get('out_of_packet'):out_of.append([lane,rank])
 statusv=classif['primary_classification'] if not out_of else 'INSUFFICIENT_EVIDENCE'
 survivors={'schema':'OSCOUT_O7_IMMUTABLE_SURVIVOR_EXPORT_V0_1_2','structural_result_sealed':True,'O7_graduated':False,'classification':statusv,'records':rows}
 atomic_json(SURV/'O7_IMMUTABLE_SURVIVORS.json',survivors)
 result={'status':'SEALED','classification':statusv,'O7_status':'RECONNAISSANCE_ONLY_NOT_GRADUATED','no_automatic_O8':True,'out_of_packet':out_of,'selected_component_records':len(rows),'equal_R7_collision_audit':coll,'science_sha256':shaj({'classification':statusv,'profiles':[(r['state_digest'],r['R7_skin_sha256'],r['profile']) for r in rows],'kills':kills,'grammar':classif})}
 checkpoint('C06_final_structural_seal',result,st);atomic_json(RESULTS/'O7_FINAL_STRUCTURAL_RESULT.json',result)
 # no authority adapter bound: post-seal shadow result must be NOT_APPLICABLE
 shadow={'status':'SHADOW_NOT_APPLICABLE','structural_result_sealed':True,'authority_adapter_bound':False,'branch_specific_DR0_DR7_run':False,'reason':'No separately certified T0W<->O7 authority adapter is bound; shadow firewall forbids improvising one from prose.','structural_classification_unchanged':statusv}
 atomic_json(RESULTS/'O7_DECISION_READINESS_SHADOW_RESULT.json',shadow);checkpoint('C07_shadow_sidecar_postseal',shadow,time.time())
 return result

# ---------- controller-stage dispatch ----------
def run_stage(stage):
 global O6; O6=import_o6()
 old=load_checkpoint(stage)
 if old is not None: status(f'SKIP verified checkpoint {stage}'); return old
 status(f'START {stage}')
 if stage=='C00_source_and_prereg_preflight':res=stage_preflight()
 elif stage=='C01_orbit_generator_parent_calibration':res=stage_calibration()
 elif stage=='C02_prototype_pool_and_selection':res=stage_prototypes()
 elif stage.startswith('HET4_m7_') or stage.startswith('HOM6_m7_') or stage.startswith('TWIN4_m7_'):
  lane,rank=stage.rsplit('_m7_',1);res=run_lane_rank(lane,int(rank))
 elif stage=='C03_profiles':
  st=time.time(); rows=run_profile_chunks();res={'status':'PASS','record_count':len(rows)};checkpoint(stage,res,st)
 elif stage=='C04_kill_matrix':
  st=time.time();rows=jload(RESULTS/'O7_SELECTED_COMPONENT_PROFILES.json')['records'];kills,ca=run_kill_tests(rows);res={'status':'PASS' if not any(str(v.get('status','')).startswith('FAIL') for v in kills.values()) else 'FAIL','kill_count':len(kills),'collision_audit':ca};checkpoint(stage,res,st)
 elif stage=='C05_classifier':
  st=time.time();rows=jload(RESULTS/'O7_SELECTED_COMPONENT_PROFILES.json')['records'];kills=jload(RESULTS/'O7_KILL_MATRIX_RESULTS.json')['outcomes'];res=run_induction_grammar_plateau(rows,kills);checkpoint(stage,res,st)
 elif stage=='C06_final_seal':
  st=time.time();rows=jload(RESULTS/'O7_SELECTED_COMPONENT_PROFILES.json')['records'];kills=jload(RESULTS/'O7_KILL_MATRIX_RESULTS.json')['outcomes'];ca=jload(RESULTS/'O7_EQUAL_R7_COLLISION_AUDIT.json');cl=jload(RESULTS/'O7_STRUCTURAL_CLASSIFICATION.json');res=final_seal(rows,kills,ca,cl);checkpoint(stage,res,st)
 else: raise KeyError(stage)
 status(f'END {stage} status={res.get("status")}')
 return res

def all_stages():
 spec=jload(SPEC_PATH);lanes=spec['frozen']['homogeneous_heterogeneous_lane_sizes']['lanes']; out=['C00_source_and_prereg_preflight','C01_orbit_generator_parent_calibration','C02_prototype_pool_and_selection']
 for lane in ('HET4','HOM6','TWIN4'):
  for r in range(int(lanes[lane]['max_m7'])+1):out.append(f'{lane}_m7_{r}')
 out += ['C03_profiles','C04_kill_matrix','C05_classifier','C06_final_seal'];return out

def main(argv=None):
 argv=argv or sys.argv[1:]
 if not argv or argv[0]=='--list':print('\n'.join(all_stages()));return 0
 stage=argv[0];res=run_stage(stage);print(json.dumps({'stage':stage,'status':res.get('status'),'classification':res.get('classification') or res.get('primary_classification')},sort_keys=True));
 if res.get('status') in ('FAIL','SOURCE_OR_SPEC_FAILURE'):return 2
 return 0

if __name__=='__main__': raise SystemExit(main())
