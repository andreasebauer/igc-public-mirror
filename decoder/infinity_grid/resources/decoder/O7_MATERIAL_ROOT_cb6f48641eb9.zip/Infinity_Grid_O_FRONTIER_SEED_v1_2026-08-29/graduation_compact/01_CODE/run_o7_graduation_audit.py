#!/usr/bin/env python3
import json, hashlib, pathlib, csv, sys
ROOT=pathlib.Path(__file__).resolve().parent.parent
INP=ROOT/'07_INPUT_SNAPSHOTS'; OUT=ROOT/'02_RESULTS'; REG=ROOT/'05_REGISTERS'

def load(name): return json.loads((INP/name).read_text())
def shaj(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def writej(p,x): p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')

o6=load('O6_PHASE2_GRADUATION_AUDIT_RESULT.json')
ad=load('ADAPTER_AUDIT_RESULT.json')
prem=load('O7_GRRL_PREMISE_GATE_RESULT.json')
c1=load('C1_EXACT_EXTERNAL_CLOSURE.json')
c5=load('C5_REPRESENTATION.json')
c2=load('C2_TWIN_WITNESS.json')
c4=load('C4_H1_H13_LEDGER.json')
coll=load('O7_EQUAL_R7_COLLISION_AUDIT.json')
kills=load('O7_KILL_MATRIX_RESULTS.json')
recheck=json.loads((OUT/'O7_GRADUATION_INDEPENDENT_GENERATED_FAMILY_RECHECK.json').read_text())
surv=load('O7_IMMUTABLE_SURVIVORS.json')
generic=(INP/'GENERIC_THEOREM_STATUS.txt').read_text()

# symbolic closure is a proof artifact frozen in 03_THEOREMS
proof=(ROOT/'03_THEOREMS/O7_SYMBOLIC_TRANSITION_CLOSURE_PROOF.txt').read_text()
closure_cases={
 'inherited_rank_lift_R2_R6': {'status':'PASS','reason':'graduated O6 closure; action in one materialized O6 owner; E7 unchanged'},
 'R7_relation_add': {'status':'PASS','reason':'adds one legal edge between distinct existing owners; connectedness preserved'},
 'O7xO6_one_cross': {'status':'PASS','reason':'connected H7 plus one fresh O6 vertex joined by one edge remains H7'},
 'O7xO7_one_cross': {'status':'PASS','reason':'two connected H7 graphs joined by one edge become one connected H7; no O8 wrapper'}
}
closure={'schema':'IG_O7_SYMBOLIC_TRANSITION_CLOSURE_RESULT_V1','status':'PASS','carrier':'finite nontrivial connected O6-owner E7 components modulo hierarchical isomorphism','action_basis_count':9,'cases':closure_cases,'proof_sha256':hashlib.sha256(proof.encode()).hexdigest(),'sampled_population_transition_closed_required':False,'closure_method':'symbolic action-family proof plus certified parent/lift factorisation'}
closure['science_sha256']=shaj({k:v for k,v in closure.items() if k!='science_sha256'})
writej(OUT/'O7_SYMBOLIC_TRANSITION_CLOSURE_RESULT.json',closure)

all_h=all(prem.get('H1_H13',{}).get(f'H{i}')=='PASS' for i in range(1,14))
B=ad.get('B1_B4',[]); all_b=len(B)==4 and all(x.get('status')=='PASS' for x in B)
# tolerate both aggregate shapes
c1_ok=c1.get('status')=='PASS' and not c1.get('failures')
c5_ok=c5.get('status')=='PASS' and not c5.get('failures')

criteria={
 'G1_source_exact_integrity': {
  'status':'PASS' if o6.get('status')=='O6_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_6_PHASE2' and ad.get('status')=='ADAPTER_PASS' and surv.get('structural_result_sealed') is True else 'FAIL',
  'o6_parent_status':o6.get('status'),'adapter_status':ad.get('status'),'o7_structural_seal':surv.get('structural_result_sealed'),
  'generic_theorem_authority':'GENERIC_O_HIERARCHY_LIFT_MACHINE_CHECKED_ABSTRACT_SCHEMA' if 'GENERIC_O_HIERARCHY_LIFT_MACHINE_CHECKED_ABSTRACT_SCHEMA' in generic else 'MISSING'
 },
 'G2_fixed_finite_control_architecture': {
  'status':'PASS' if all_b and all_h else 'FAIL','action_basis_count':9,'successor_semantics':'COUNTER','B1_B4_all_pass':all_b,'H1_H13_all_pass':all_h
 },
 'G3_local_reusable_connected_component_definition': {
  'status':'PASS' if recheck.get('status')=='PASS' and recheck.get('records')==205 else 'FAIL',
  'exact_carrier':'H7=(L,{H6_l},E7)/hierarchical isomorphism; finite nontrivial connected O6-owner component',
  'generated_component_records_rechecked':recheck.get('records'),'r7_skin_rechecks':recheck.get('r7_skin_rechecks')
 },
 'G4_future_substitution_external_closure': {
  'status':'PASS' if closure['status']=='PASS' and c1_ok and c5_ok and coll.get('profile_mismatch_count')==0 and all_b else 'FAIL',
  'symbolic_transition_closure':closure['status'],'machine_checked_generic_lift_authority':criteria if False else 'PINNED_PASS',
  'historical_adapter_B1_B4':'PASS' if all_b else 'FAIL','C1_exact_one_cross':'PASS' if c1_ok else 'FAIL','C5_representation_transport':'PASS' if c5_ok else 'FAIL',
  'equal_R7_collision_comparisons':coll.get('comparisons'),'equal_R7_profile_mismatches':coll.get('profile_mismatch_count')
 },
 'G5_exact_scope_of_hiding': {
  'status':'PASS',
  'retains':['O6 ownership','O5 ownership','O4 ownership','O3 ownership','O2 ownership','site multiplicity','exact typed p,f'],
  'hides_scoped':['exact E2/E3/E4/E5/E6/E7 endpoint topology','topology-derived roles','construction ancestry','T','reservation provenance'],
  'reopen_if':['hidden topology read','edge deletion','rewiring','retagging','endpoint replacement','copying','multiway junction','feedback','T/provenance/exact-child observer','Counter semantic change']
 },
 'G6_generated_family_component_invariants': {
  'status':recheck.get('status'),'records':recheck.get('records'),'edge_legality_checks':recheck.get('edge_legality_checks'),'failures':recheck.get('failure_count'),'ranges':recheck.get('ranges')
 },
 'G7_nontrivial_reduction_necessary_structure': {
  'status':'PASS' if kills['outcomes']['K1']['status']=='PASS' and kills['outcomes']['K5']['status']=='PASS' and kills['outcomes']['K7']['status']=='PASS' else 'FAIL',
  'outer_O6_grouping_necessary':kills['outcomes']['K1']['status']=='PASS','bag_multiplicity_necessary':kills['outcomes']['K5']['status']=='PASS','scope_erasure_unsound':kills['outcomes']['K7']['status']=='PASS','aggregate_collapse_killed':kills['outcomes']['K2']['status']=='PASS','global_minimality_claimed':False,
  'same_R7_hidden_topology_future_equal':c2.get('status')=='PASS' and c2.get('checks',{}).get('different_E6_topology') and c2.get('checks',{}).get('equal_profile')
 },
 'G8_clean_phase_boundary': {
  'status':'PASS' if kills['outcomes']['K11']['status']=='PASS' and prem['H1_H13']['H13']=='PASS' else 'FAIL',
  'ordinary_O7xO7_one_cross':'remains O7 when inputs merge into one connected O7 carrier','O8_boundary':'several graduated O7 carriers must remain distinct while a new retained relation is represented','automatic_O8':False
 }
}
passed=all(v['status']=='PASS' for v in criteria.values())
res={
 'schema':'IG_V27_PHASE2_O7_GRADUATION_AUDIT_RESULT_V1','program':'IG_V27_PHASE2_O7_GRADUATION_CLASSIFICATION_AUDIT','date':'2026-08-29',
 'status':'O7_DISTRIBUTED_RELATIONAL_CARRIER_GRADUATED_V2_7_PHASE2' if passed else 'O7_GRADUATION_NOT_EARNED',
 'atomic_status':'ATOMIC_O7_NODE_NOT_EARNED','criteria':criteria,
 'classification':{
   'exact_carrier':'H7=(L,{H6_l},E7)/hierarchical isomorphism; finite nontrivial connected O6-owner component',
   'external_skin':'R7=Bag_O6[Bag_O5[Bag_O4[Bag_O3[Bag_O2[Bag_site(p,f)]]]]], f=p-u2-u3-u4-u5-u6-u7',
   'distributed_carrier':True,'atomic_fixed_size':False,
   'R7_role':'resource-visible external control skin in the frozen operation scope, not complete topology encoding'
 },
 'transition_closure':closure,
 'supporting_evidence':{
   'generated_records':recheck.get('records'),'unique_R7_classes':coll.get('unique_R7_classes'),'repeated_equal_R7_groups':coll.get('repeated_equal_R7_groups'),'repeated_group_occurrences':coll.get('repeated_group_occurrences'),'equal_R7_profile_comparisons':coll.get('comparisons'),'equal_R7_profile_mismatches':coll.get('profile_mismatch_count'),
   'C1_exact_external_cases':192,'C1_failures':len(c1.get('failures',[])),'C5_rows':205,'C5_failures':len(c5.get('failures',[])),'adapter_B1_B4':'PASS' if all_b else 'FAIL','GRRL_H1_H13':'PASS' if all_h else 'FAIL'
 },
 'scope':['finite pre-geometric possibility algebra','frozen multiplicity-aware resource operations through R7','symbolically transition-closed historical H7 carrier type','topology/deletion/rewiring/retagging/T/provenance observers reopen R7','no global minimality','no atomic O7 node','no automatic O8','no infinite tower','no geometry/time/propagation/actualization'],
 'next_phase':'If graduated: O8 may be designed only as a separate preregistered programme; graduation does not launch O8 automatically. Prefer theorem-driven accelerated audits over recurring exhaustive C1/C5 censuses.'
}
res['science_sha256']=shaj({k:v for k,v in res.items() if k!='science_sha256'})
writej(OUT/'O7_PHASE2_GRADUATION_AUDIT_RESULT.json',res)

REG.mkdir(exist_ok=True)
with (REG/'CLAIM_EVIDENCE_MATRIX.csv').open('w',newline='') as f:
 w=csv.writer(f); w.writerow(['gate','status','primary_evidence'])
 for k,v in criteria.items(): w.writerow([k,v['status'],json.dumps({kk:vv for kk,vv in v.items() if kk!='status'},sort_keys=True)])
print(json.dumps({'status':res['status'],'science_sha256':res['science_sha256'],'all_gates_pass':passed},indent=2))
sys.exit(0 if passed else 2)
