import os, json, importlib.util, pathlib, collections, sys
os.environ['OSCOUT_DATA_ROOT']='/mnt/data/O7_CLOSEOUT_FINAL_RUN'
P=pathlib.Path('/mnt/data/O7_CLOSEOUT_FINAL_RUN/02_CODE/o7_live_engine.py')
spec=importlib.util.spec_from_file_location('o7',P); o7=importlib.util.module_from_spec(spec); sys.modules['o7']=o7; spec.loader.exec_module(o7)
o7.O6=o7.import_o6()
ports,pairs=o7.O6.load_rules(); pairset=set(pairs)
rows=json.load(open('/mnt/data/O7_CLOSEOUT_FINAL_RUN/08_SURVIVORS/O7_IMMUTABLE_SURVIVORS.json'))['records']
mp=o7.load_parent_records()
fail=[]; counts=collections.Counter(); r7m=0; exact=0; ranges={k:[] for k in ['K6','m7','beta7','beta_flat','N','d','r','F','g']}
for idx,row in enumerate(rows):
    try:
        parents=[mp[x] for x in row['parent_ids']]
        ctx=o7.LaneContext(f'G7_{idx}',parents,row['parent_ids'])
        edges=tuple(tuple(e) for e in row['edges'])
        # connectivity / nontrivial
        comps=o7.graph_components(ctx.n,edges)
        if ctx.n<2 or len(edges)<1 or len(comps)!=1 or len(comps[0])!=ctx.n:
            fail.append([idx,'connectivity',ctx.n,len(edges),comps])
        # edge legality & exact paths
        used=collections.Counter()
        for e in edges:
            c,p,a,d,q,b=o7.eparts(e)
            if not (0<=c<d<ctx.n): fail.append([idx,'owner_scope',e])
            if (a,b) not in pairset: fail.append([idx,'bridge_pair',a,b])
            try:
                pp,ff=o7.site_at(ctx.parents[c].h6,p); qq,gg=o7.site_at(ctx.parents[d].h6,q)
            except Exception as ex:
                fail.append([idx,'bad_path',repr(ex),e]); continue
            used[(c,p,a)]+=1; used[(d,q,b)]+=1
            if used[(c,p,a)]>ff[a]: fail.append([idx,'oversub_left',e])
            if used[(d,q,b)]>gg[b]: fail.append([idx,'oversub_right',e])
            exact+=1
        ac=o7.accounting(ctx,edges)
        if not ac['ok']: fail.append([idx,'accounting',ac])
        for k in ranges: ranges[k].append(ac[k])
        # independently materialize and compare frozen R7 skin
        cur=o7.current_owner_data(ctx,edges); skin=o7.r7_skin_sig(cur)
        if skin!=row['R7_skin_sha256']: fail.append([idx,'skin_mismatch',skin,row['R7_skin_sha256']])
        else: r7m+=1
        counts[row['lane']]+=1
    except Exception as ex:
        fail.append([idx,'exception',repr(ex)])
res={
 'schema':'IG_O7_GRADUATION_INDEPENDENT_GENERATED_FAMILY_RECHECK_V1',
 'status':'PASS' if not fail else 'FAIL',
 'records':len(rows),'lane_counts':dict(counts),'edge_legality_checks':exact,'r7_skin_rechecks':r7m,
 'failure_count':len(fail),'failures':fail[:50],
 'ranges':{k:[min(v),max(v)] if v else None for k,v in ranges.items()}
}
import hashlib
core=dict(res); core.pop('status',None)
res['science_sha256']=hashlib.sha256(json.dumps(core,sort_keys=True,separators=(',',':')).encode()).hexdigest()
out=pathlib.Path('/mnt/data/o7_graduation_work/O7_GRADUATION_INDEPENDENT_GENERATED_FAMILY_RECHECK.json')
out.write_text(json.dumps(res,indent=2,sort_keys=True)+'\n')
print(json.dumps(res,indent=2))
